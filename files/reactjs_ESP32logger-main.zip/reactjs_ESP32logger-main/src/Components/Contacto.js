import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Contacto() {
    const handleLogout = () => {
        localStorage.removeItem('Auth Token');
        navigate('/login')
    }
    let navigate = useNavigate();
    useEffect(() => {
    }, [])
    return (
        <div>
            Contact Page

            <button onClick={handleLogout}>Log out</button>
        </div>
    )
}
