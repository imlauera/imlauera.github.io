import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import FormLabel from '@mui/material/FormLabel';
import FormControl from '@mui/material/FormControl';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormHelperText from '@mui/material/FormHelperText';
import Switch from '@mui/material/Switch';
import Typography from '@mui/material/Typography';
import { alpha, styled } from '@mui/material/styles';
import { red, yellow } from '@mui/material/colors';
import { app } from '../firebase-config';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getDatabase, set, onValue, query, limitToLast, get, ref, update } from 'firebase/database';


const RedSwitch = styled(Switch)(({ theme }) => ({
  '& .MuiSwitch-switchBase.Mui-checked': {
    color: red[600],
    '&:hover': {
      backgroundColor: alpha(red[600], theme.palette.action.hoverOpacity),
    },
  },
  '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
    backgroundColor: red[600],
  },
}));



const YellowSwitch = styled(Switch)(({ theme }) => ({
  '& .MuiSwitch-switchBase.Mui-checked': {
    color: yellow[600],
    '&:hover': {
      backgroundColor: alpha(yellow[600], theme.palette.action.hoverOpacity),
    },
  },
  '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
    backgroundColor: yellow[600],
  },
}));

export default function SwitchesGroup() {
    let navigate = useNavigate();

    const [state, setState] = React.useState({
        led_amarillo: false,
        led_rojo: false,
        led_verde: false,
    });
    const [loading, setLoading] = useState(true);


    const changeLed = async (led,value) => {
      setLoading(true);
      const authentication = getAuth();
      const database = getDatabase(app);
      onAuthStateChanged(authentication, async (user) => {
          if (user){
              update(ref(database, 'UsersData/' + user.uid +'/writtings/tempLogger/'),{
                  [led]:value
              })
          }
          setLoading(false);
      });
  };


    const stateSetup = async () => {
      setLoading(true);
      const authentication = getAuth();
      const database = getDatabase(app);
      onAuthStateChanged(authentication, async (user) => {
         if (user){
              let recentReadingsRef = await query(ref(database,'UsersData/' + user.uid +'/writtings/tempLogger/'));
              //const snapshot = await get(recentReadingsRef)
              onValue(recentReadingsRef, (snapshot) => {
                  const data = snapshot.val();
                  //setPosts(snapshot.val())
                  setState({
                      ...state,
                      led_amarillo: data.led_amarillo,
                      led_rojo: data.led_rojo,
                      led_verde: data.led_verde,
                  });
                  setLoading(false);
              },
              {
                  onlyOnce: true 
              });


          }
      });

  };



  useEffect(() => {
        let authToken = localStorage.getItem('Auth Token')

        if (authToken){
            stateSetup()
        }

        if (!authToken) {
            navigate('/login')
        }
        setInterval(() => {
            stateSetup()
        }, 8000);


  }, []);

  const handleChange = (event) => {
    setState({
      ...state,
      [event.target.name]: event.target.checked,
    });
    changeLed(event.target.name,event.target.checked);
  };

  return (
      <>
        <FormControl component="fieldset" variant="standard">
          <FormLabel component="legend">
              <Typography
                variant="h6"
                sx={{
                  fontWeight: 900,
                  textDecoration: 'none',
                }}
              >
                LEDs
              </Typography>
          </FormLabel>
          <FormGroup>
            <FormControlLabel
              control={
                <YellowSwitch checked={state.led_amarillo} onChange={handleChange} name="led_amarillo" />
              }
              label="Amarillo"
            />
            <FormControlLabel
              control={
                <RedSwitch checked={state.led_rojo} onChange={handleChange} name="led_rojo" />
              }
              label="Rojo"
            />
            <FormControlLabel
              control={
                <Switch color="success" checked={state.led_verde} onChange={handleChange} name="led_verde" />
              }
              label="Verde"
            />
          </FormGroup>
        </FormControl>
      </>
  );
}
