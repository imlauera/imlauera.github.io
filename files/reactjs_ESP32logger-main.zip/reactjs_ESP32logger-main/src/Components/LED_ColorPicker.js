import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Switch from '@mui/material/Switch';
import Typography from '@mui/material/Typography';
import { alpha, styled } from '@mui/material/styles';
import { red, yellow } from '@mui/material/colors';
import FormLabel from '@mui/material/FormLabel';
import FormControl from '@mui/material/FormControl';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormHelperText from '@mui/material/FormHelperText';
import { app } from '../firebase-config';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getDatabase, set, onValue, query, limitToLast, get, ref, update } from 'firebase/database';



export default function ColorPicker() {
    let navigate = useNavigate();
    const [color, setColor] = React.useState({
        WS2812b1: "#ff0000",
        WS2812b2: "#ff0000",
        WS2812b3: "#ff0000",
        WS2812b4: "#ff0000",
    });
    const [state, setState] = React.useState({
        WS2812b1: false,
        WS2812b2: false,
        WS2812b3: false,
        WS2812b4: false
    });

    const [loading, setLoading] = useState(true);


    const ledAction = async (led,color_hex,checked) => {
      if(color_hex == 0){
          color_hex = color[led];
      }
      setLoading(true);
      const authentication = getAuth();
      const database = getDatabase(app);
      onAuthStateChanged(authentication, async (user) => {
          if (user){
              let arduino_color = '0x'+color_hex.substring(1)
              update(ref(database, 'UsersData/' + user.uid +'/writtings/tempLogger/'),{
                  [led]:[arduino_color,checked,color_hex]
              })
          }
          setLoading(false);
      });
  };

    const stateSetup = async () => {
      setLoading(true);
      const authentication = getAuth();
      const database = getDatabase(app);
      onAuthStateChanged(authentication, async (user) => {
         if (user){
              let recentReadingsRef = await query(ref(database,'UsersData/' + user.uid +'/writtings/tempLogger/'));
              //const snapshot = await get(recentReadingsRef)
              onValue(recentReadingsRef, (snapshot) => {
                  const data = snapshot.val();
                  //setPosts(snapshot.val())
                  setColor({
                      ...color,
                      WS2812b1:data.WS2812b1[2],
                      WS2812b2:data.WS2812b2[2],
                      WS2812b3:data.WS2812b3[2],
                      WS2812b4:data.WS2812b4[2]
                  });
                  setState({
                      ...state,
                      WS2812b1:data.WS2812b1[1],
                      WS2812b2:data.WS2812b2[1],
                      WS2812b3:data.WS2812b3[1],
                      WS2812b4:data.WS2812b4[1]
                  });

                  setLoading(false);
              },
              {
                  onlyOnce: true 
              });

         }
      });

  };


  useEffect(() => {
        let authToken = localStorage.getItem('Auth Token')

        if (authToken){
            stateSetup()
        }

        if (!authToken) {
            navigate('/login')
        }
        setInterval(() => {
            stateSetup()
        }, 8000);


  }, []);



  const handleChange = (event) => {
    setState({
      ...state,
      [event.target.name]: event.target.checked,
    });
    ledAction(event.target.name,0,event.target.checked)
  };

  const handleChange_color = (event) => {
    setColor({
      ...color,
      [event.target.name]: event.target.value,
    });

    setState({
      ...state,
      [event.target.name]: true,
    });
    ledAction(event.target.name,event.target.value,true)
  };



  return (
      <>
        <FormControl component="fieldset" variant="standard">
          <FormLabel component="legend">
              <Typography
                variant="h6"
                sx={{
                  fontWeight: 900,
                  textDecoration: 'none',
                }}
              >
                LEDs WS2812b
              </Typography>
          </FormLabel>
          <FormGroup>
            <FormControlLabel
              control={
                <><input type="color" value={color.WS2812b1} onChange={handleChange_color} name="WS2812b1" />
                <Switch color="info" checked={state.WS2812b1} onChange={handleChange} name="WS2812b1" /></>
              }
              label="1"
            />
            <FormControlLabel
              control={
                <><input type="color" value={color.WS2812b2} onChange={handleChange_color} name="WS2812b2" />
                <Switch color="info" checked={state.WS2812b2} onChange={handleChange} name="WS2812b2" /></>
              }
              label="2"
            />
            <FormControlLabel
              control={
                <><input type="color" value={color.WS2812b3} onChange={handleChange_color} name="WS2812b3" />
                <Switch color="info" checked={state.WS2812b3} onChange={handleChange} name="WS2812b3" /></>
              }
              label="3"
            />
            <FormControlLabel
              control={
                <><input type="color" value={color.WS2812b4} onChange={handleChange_color} name="WS2812b4" />
                <Switch color="info" checked={state.WS2812b4} onChange={handleChange} name="WS2812b4" /></>
              }
              label="4"
            />
          </FormGroup>
        </FormControl>
      </>
  );
}
