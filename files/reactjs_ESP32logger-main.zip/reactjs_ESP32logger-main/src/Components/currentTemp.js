import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { app } from '../firebase-config';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getDatabase, set, query, onValue, limitToLast, get, ref, update } from 'firebase/database';
import Typography from '@mui/material/Typography';


export default function CurrentTemp() {
  let navigate = useNavigate();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
    //asd

  const fetchPost = async () => {
      setLoading(true);
      const authentication = getAuth();
      const database = getDatabase(app);
      onAuthStateChanged(authentication, async (user) => {

          if (user){
              console.log(user)
              let recentReadingsRef = await query(ref(database,'UsersData/' + user.uid +'/readings/'), limitToLast(1));
              //const snapshot = await get(recentReadingsRef)
              onValue(recentReadingsRef, (snapshot) => {
                  setPosts(snapshot.val())
                  setLoading(false);
              },
              {
                  onlyOnce: true 
              });

          }
      });
  };

  useEffect(() => {
        let authToken = localStorage.getItem('Auth Token')
        console.log(authToken)
        if (authToken) {
            fetchPost();
        }

        if (!authToken) {
            navigate('/login')
        }

  }, []);
  return (
    <div>
    <Typography
      variant="h6"
      sx={{
        textDecoration: 'none',
      }}
    >
      Últimos Registros
    </Typography>
    <p>{loading && <p><h1>⌛</h1>Cargando...</p>}</p>
    <h3> {Object.keys(posts).map(value => 
        <ul>
        <li><big>⏲</big> {posts[value].gmtTime} </li>
        <li><big>🌡️</big> {posts[value].temperature_c} °C</li>
        <li><big>🌡️</big> {posts[value].temperature_f} °F</li>
        <li><big>💡</big>{posts[value].ldr}</li>
        <li>{posts[value].tilt==="1" ? <big>👆</big>:<big>👇</big> } (Orientación)</li>
        </ul>
        )}
      </h3>

      <button onClick={fetchPost}> Actualizar </button>
    </div>
  );
}
