import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { experimentalStyled as styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import ImgMediaCard from './Common/ImgMediaCard';
import SwitchesGroup from './Switch';
import Display from './Display';
import BuzzerButton from './Buzzer';
import ColorPicker from './LED_ColorPicker';
import CurrentTemp from './currentTemp';
import { app } from '../firebase-config';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getDatabase, set, query, onValue, limitToLast, get, ref, update } from 'firebase/database';
import Typography from '@mui/material/Typography';



const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(2),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function GridOfCards() {
  let navigate = useNavigate();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);


  const fetch = async () => {
      setLoading(true);
      const authentication = getAuth();
      const database = getDatabase(app);

      onAuthStateChanged(authentication, (user) => {

          if (user){
              console.log(user)
              onValue(query(ref(database,'Products/')), (snapshot) => {
                  console.log(snapshot.val());
                  setPosts(snapshot.val())
                  setLoading(false);
              },
              {
                  onlyOnce: true 
              });
          }
      });
  };
  useEffect(() => {
        let authToken = localStorage.getItem('Auth Token')
        console.log(authToken)
        fetch();
  }, []);



  return (
    <Box sx={{ flexGrow: 1 }}>
      { loading ?  <p>{loading && <p><h1>⌛</h1>Cargando...</p>}</p> :
      <Grid container spacing={{ xs: 2, md: 3 }} columns={{ xs: 4, sm: 8, md: 12 }}>
        {posts.map((post,index) => (
          <Grid item xs={2} sm={4} md={4} key={index}>
            <ImgMediaCard 
                title={post.title}
                desc={post.desc}
                id={index}
                img={post.img}
            />
          </Grid>
        ))}
      </Grid>
      }
    </Box>
  );
}
