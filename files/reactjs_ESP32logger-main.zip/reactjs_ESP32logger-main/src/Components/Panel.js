import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import SwitchesGroup from './Switch';
import Display from './Display';
import BuzzerButton from './Buzzer';
import ColorPicker from './LED_ColorPicker';
import CurrentTemp from './currentTemp';
import Typography from '@mui/material/Typography';


export default function Panel() {
    const handleLogout = () => {
        localStorage.removeItem('Auth Token');
        navigate('/login')
    }


    let navigate = useNavigate();
    useEffect(() => {
        let authToken = localStorage.getItem('Auth Token')
        console.log(authToken)

        if (!authToken) {
            navigate('/login')
        }
    }, [])
    return (
        <div>
            <div >
                <CurrentTemp/>
            </div>
            <hr style={{border:'2px solid #1976d2'}}/>
            <Typography
              variant="h6"
              sx={{
                textDecoration: 'none',
              }}
            >
              Controles
            </Typography>
            <hr style={{border:'2px solid #1976d2'}}/>

            <Display/>
            <SwitchesGroup/>
            <BuzzerButton/>
            <ColorPicker/>
            <hr style={{border:'2px solid #1976d2'}}/>
        </div>
    )
}
