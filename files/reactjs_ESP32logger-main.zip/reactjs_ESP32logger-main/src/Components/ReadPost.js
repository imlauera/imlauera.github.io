import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { experimentalStyled as styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import ImgMediaCard from './Common/ImgMediaCard';
import LargeImgMediaCard from "./Common/LargeImgMediaCard"
import SwitchesGroup from './Switch';
import Display from './Display';
import BuzzerButton from './Buzzer';
import ColorPicker from './LED_ColorPicker';
import CurrentTemp from './currentTemp';
import { app } from '../firebase-config';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getDatabase, set, onValue, query, limitToLast, get, ref, update } from 'firebase/database';
import Typography from '@mui/material/Typography';
import { withRouter } from "react-router-dom";
import {
  useParams
} from "react-router-dom";


const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(2),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function ReadPost() {
  let navigate = useNavigate();
  let { id } = useParams();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);


  const fetch = async () => {
      setLoading(true);
      const authentication = getAuth();
      const database = getDatabase(app);
      onAuthStateChanged(authentication, async (user) => {

          if (user){
              console.log(user)
              let recentReadingsRef = await query(ref(database,`Products/${id}`));
              //const snapshot = await get(recentReadingsRef)
              onValue(recentReadingsRef, (snapshot) => {
                  setPosts(snapshot.val())
                  setLoading(false);
              },
              {
                  onlyOnce: true 
              });

          }
      });
  };
  
  useEffect(() => {
        let authToken = localStorage.getItem('Auth Token')
        console.log(authToken)
        fetch();
  }, []);



  return (
    <Box sx={{ flexGrow: 1 }}>
        <LargeImgMediaCard 
            title={posts.title}
            desc={posts.large_desc}
            img={posts.img}
        />
    </Box>
  );
}
