import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Button from '@mui/material/Button';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import CancelIcon from '@mui/icons-material/Cancel';
import SendIcon from '@mui/icons-material/Send';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import { app } from '../firebase-config';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getDatabase, set, onValue, query, limitToLast, get, ref, update } from 'firebase/database';


export default function BuzzerButton() {
  let navigate = useNavigate();

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(true);

  const buzzSend = async (value) => {
      setLoading(true);
      const authentication = getAuth();
      const database = getDatabase(app);
      onAuthStateChanged(authentication, async (user) => {
          if (user){
              update(ref(database, 'UsersData/' + user.uid +'/writtings/tempLogger/'),{
                  buzzer:value
              })
          }
          setLoading(false);
          setSubmitted(value);
      });
  };
    const stateSetup = async () => {
      const authentication = getAuth();
      const database = getDatabase(app);
      onAuthStateChanged(authentication, async (user) => {
         if (user){
              let recentReadingsRef = await query(ref(database,'UsersData/' + user.uid +'/writtings/tempLogger/'));
              //const snapshot = await get(recentReadingsRef)
              onValue(query(ref(database,'Products/')), (snapshot) => {

                  const data = snapshot.val();
                  //setPosts(snapshot.val())

                  if (data.buzzer === true)
                    setSubmitted(true);
                  else
                    setSubmitted(false);

              },
              {
                  onlyOnce: true 
              });
          }
      });

  };


  useEffect(() => {
        let authToken = localStorage.getItem('Auth Token')

        if (authToken){
            stateSetup()
        }

        if (!authToken) {
            navigate('/login')
        }
        setInterval(() => {
            stateSetup()
        }, 8000);

  }, []);


  return (
    <Box
      component="form"
      sx={{
        '& > :not(style)': { m: 1, width: '25ch' },
      }}
      noValidate
      autoComplete="off"
    >

      { submitted 
          ?
              <Button variant="contained" color="warning" startIcon={<CancelIcon />} onClick={()=>buzzSend(false)}>
                Cancelar
              </Button>
          :
              <Button variant="contained" color="primary" startIcon={<NotificationsActiveIcon />} onClick={()=>buzzSend(true)}>
                Buzzer
              </Button>
      }
      </Box>
  );
}
