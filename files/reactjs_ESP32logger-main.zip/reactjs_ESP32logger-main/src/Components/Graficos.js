import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import SwitchesGroup from './Switch';
import Display from './Display';
import BuzzerButton from './Buzzer';
import ColorPicker from './LED_ColorPicker';
import CurrentTemp from './currentTemp';
import Typography from '@mui/material/Typography';
import {useState} from 'react';
import { app } from '../firebase-config';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getDatabase, onValue, set, query, limitToLast, get, ref, update } from 'firebase/database';
import { Line } from 'react-chartjs-2';
import {Chart as ChartJS, Title, Tooltip, LineElement, Legend, CategoryScale, LinearScale, PointElement, Filler} from 'chart.js';



ChartJS.register(
  Title, Tooltip, LineElement, Legend,
  CategoryScale, LinearScale, PointElement, Filler
)



export default function Graficos() {
  let navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [data, setData]= useState();

  const getData = async () => {
      setLoading(true);
      const authentication = getAuth();
      const database = getDatabase(app);
      onAuthStateChanged(authentication, (user) => {
          if (user){
              let recentReadingsRef = query(ref(database,'UsersData/' + user.uid +'/readings/'), limitToLast(130));

              onValue(recentReadingsRef, (snapshot) => {
                  const data = snapshot.val();
                  var myData = Object.keys(data).map(key => {
                      return data[key];
                  })

                  let temp = [];
                  myData.filter(item => temp.push(item.temperature_c))
                  let ldr = [];
                  myData.filter(item => ldr.push(item.ldr))
                  let time = [];
                  myData.filter(item => time.push(item.gmtTime))

                  setData({
                    //labels:["Jan","Feb", "March", "April", "May", "June", "July", "August", "September", "Oct", "Nov", "Dec"],
                    labels:time,
                    datasets:[
                      {
                        label:"Temperatura",
                        //data:[10, 20, 30, 42, 51, 82, 31, 59, 61, 73, 91, 58],
                        data:temp,
                        backgroundColor:'#ff0000dd',
                        borderColor:'#1976d2',
                        tension:0.4,
                        fill:true,
                        pointStyle:'rectRot',
                        pointRadius: 5,
                        pointBorderColor:'blue',
                        pointBackgroundColor:'#fff',
                        showLine:true,
                      },
                      {
                        label:"LDR",
                        //data:[10, 20, 30, 42, 51, 82, 31, 59, 61, 73, 91, 58],
                        data:ldr,
                        backgroundColor:'#ffcc01dd',
                        borderColor:'#1976d2',
                        tension:0.4,
                        fill:true,
                        pointStyle:'rectRot',
                        pointRadius: 5,
                        pointBorderColor:'blue',
                        pointBackgroundColor:'#fff',
                        showLine:true,
                        hidden:true
                      }
                    ]
                  })
                  setLoading(false);
              },
              {
                  onlyOnce: true 
              });

          }
      });
  };


  useEffect(() => {
    let authToken = localStorage.getItem('Auth Token')
    console.log(authToken)
    if (!authToken) {
        navigate('/login')
    }
    getData()
  }, []);





  return (
      <> { loading ?  <p>{loading && <p><h1>⌛</h1>Cargando...</p>}</p> :
          <div style={{overflow:'auto'}}>
              <div style={{width:'1300px', height:'auto'}}>
                  <Line data={data}>Hello</Line>
              </div>
          </div>
      }</>
  );

}
