import React, { useRef, forwardRef} from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Button from './Button';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { getDatabase, set, query, limitToLast, get, ref, update } from 'firebase/database';
import { ToastContainer, toast } from 'react-toastify';
import {
  useNavigate
} from "react-router-dom";



const BasicTextFields = ({ title, id, auth }) => {
  const emailRef = useRef("");
  const passwordRef = useRef("");

  let navigate = useNavigate();

  const handleAction = () => {
  const authentication = getAuth();
  const email = emailRef?.current.value;
  const password = passwordRef?.current.value;
    if (id === 1) {
      signInWithEmailAndPassword(authentication, email, password)
        .then((response) => {
          navigate('/')
          console.log(/mamita posho/)
          console.log(response)
          auth(response)
          //localStorage.setItem('Auth Token', response._tokenResponse.refreshToken)
        })
        .catch((error) => {
          console.log(error.code)
          if (error.code === 'auth/wrong-password') {
            toast.error('Please check the Password');
          }
          if (error.code === 'auth/invalid-email') {
            toast.error('Invalid Email');
          }
          if (error.code === 'auth/user-not-found') {
            toast.error('Please check the Email');
          }
        })
    }
    if (id === 2) {
      createUserWithEmailAndPassword(authentication, email, password)
        .then((response) => {
          navigate('/')
          //localStorage.setItem('Auth Token', response._tokenResponse.refreshToken)
          auth(response)
        })
        .catch((error) => {
          if (error.code === 'auth/email-already-in-use') {
            toast.error('Email Already in Use');
          }
        })
    }
  }

    return (
        <div>
            <div className="heading-container">
                <h3>
                    {title} Form
                </h3>
            </div>

            <Box
                component="form"
                sx={{
                    '& > :not(style)': { m: 1, width: '25ch' },
                }}
                noValidate
                autoComplete="off"
            >
                <TextField
                    id="email"
                    label="Enter the Email"
                    variant="outlined"
                    inputRef={emailRef}
                    //onChange={(e) => setEmail(e.target.value)}
                />
                <TextField
                    id="password"
                    type="password"
                    label="Enter the Password"
                    variant="outlined"
                    inputRef={passwordRef}
                    //onChange={(e) => setPassword(e.target.value)}
                />
            </Box>

            <Button title={title} handleAction={handleAction}/>
        </div>
    );
}
export default BasicTextFields;
