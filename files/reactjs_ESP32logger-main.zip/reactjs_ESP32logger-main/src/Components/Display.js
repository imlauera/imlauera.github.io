import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import FormGroup from '@mui/material/FormGroup';
import Button from '@mui/material/Button';
import { app } from '../firebase-config';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getDatabase, set, query, onValue, limitToLast, get, ref, update } from 'firebase/database';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


export default function Display() {
  let navigate = useNavigate();
  const displayRef = useRef();

  const [loading, setLoading] = useState(true);

  const displaySend = async () => {
      setLoading(true);
      const oled = displayRef?.current.value;
      const authentication = getAuth();
      const database = getDatabase(app);
      onAuthStateChanged(authentication, async (user) => {
          if (user){
              if (oled != ""){
                  update(ref(database, 'UsersData/' + user.uid +'/writtings/tempLogger/'),{
                      oled
                  })
                  toast.success('Listo');
              }else{
                  toast.error('No se puede enviar un texto vacio');
              }
          }
          setLoading(false);

      });
  };

    const stateSetup = async () => {
      const authentication = getAuth();
      const database = getDatabase(app);
      onAuthStateChanged(authentication, async (user) => {
         if (user){
              let recentReadingsRef = await query(ref(database,'UsersData/' + user.uid +'/writtings/tempLogger/'));
              //const snapshot = await get(recentReadingsRef)
              onValue(recentReadingsRef, (snapshot) => {
                  const data = snapshot.val();
                  if(displayRef.current != null) displayRef.current.value = data.oled;
                  //setPosts(snapshot.val())
                  setLoading(false);
              },
              {
                  onlyOnce: true 
              });

          }
      });

  };




  useEffect(() => {
        let authToken = localStorage.getItem('Auth Token')
        console.log(authToken)
        if (authToken){
            stateSetup()
        }


        if (!authToken) {
            navigate('/login')
        }


  }, []);

  return (
    <FormGroup row sx={{ justifyContent: 'center', }}>
      <TextField sx={{width:'70%'}} inputRef={displayRef} id="display" label={ loading ? "⌛ Cargando...": "Ingresa el Mensaje a Mostrar en el Display" } variant="filled" />
      <Button variant="contained" onClick={displaySend} disableElevation>ok</Button>
    </FormGroup>

  );
}
