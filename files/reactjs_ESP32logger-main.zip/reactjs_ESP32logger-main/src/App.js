import { useState, useEffect, useRef } from 'react';
import './App.css';
import Form from './Components/Common/Form';
import Home from './Components/Home';
import Panel from './Components/Panel';
import ResponsiveAppBar from './Components/Common/ResponsiveAppBar';
import Box from '@mui/material/Box';
import GridOfCards from './Components/GridOfCards';
import Contacto from './Components/Contacto';
import currentTemp from './Components/currentTemp';
import Graficos from './Components/Graficos';
import ReadPost from './Components/ReadPost';
import {
  Routes,
  Route,
  useNavigate
} from "react-router-dom";
import { app } from './firebase-config';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { getDatabase, set, query, limitToLast, get, ref, update } from 'firebase/database';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';



function App() {
  //const [email, setEmail] = useState('');
  let navigate = useNavigate();

  const [logged, setLogged] = useState(false);

  const auth = (response) => {
      localStorage.setItem('Auth Token', response._tokenResponse.refreshToken)
      setLogged(true);
  };

  useEffect(() => {

    let authToken = localStorage.getItem('Auth Token')
    if (!authToken) {
        navigate('/login')
    }

  }, [])
  return (
    <div className="App" style={{marginTop:'80px'}}>
      <>
        <ResponsiveAppBar />
        <ToastContainer />
        <Box style={{maxWidth:'1500px',margin:'auto'}}>
            <Routes>
              <Route
                path='/'
                element={
                  <GridOfCards />}
              />
              <Route
                path='/login'
                element={
                    <>
                  <Form
                    title="Login"
                    auth={auth}
                    id={1}
                  />
                  <Form
                    title="Register"
                    auth={auth}
                    id={2}
                  />
                    </>
                }
              />
              <Route
                path='/register'
                element={
                  <Form
                    title="Register"
                    id={2}
                    auth={auth}
                  />}
              />

              <Route
                path='/read/:id'
                element={
                  <ReadPost />}
              />
              <Route
                path='/home'
                element={
                  <Home />}
              />
              <Route
                path='/graficos'
                element={
                  <Graficos />}
              />
              <Route
                path='/panel'
                element={
                  <Panel />}
              />
              <Route
                path='/contacto'
                element={
                  <Contacto />}
              />
            </Routes>
      </Box>
      </>
    </div>
  );
}

export default App;
