import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyAXZzTwC_Nqh-ZCepllSi8XKTnOcd6UtY4",
  authDomain: "esp32-bd971.firebaseapp.com",
  databaseURL: "https://esp32-bd971-default-rtdb.firebaseio.com",
  projectId: "esp32-bd971",
  storageBucket: "esp32-bd971.appspot.com",
  messagingSenderId: "174067091908",
  appId: "1:174067091908:web:c70265a69ddb439c0a3c91",
  measurementId: "G-MYPPQJS3MT"
};

export const app = initializeApp(firebaseConfig);
