#include <stdio.h>
#include <stdlib.h>

void printlista(int lista[])
{
    int i;
    for(i=0;i<6;i++)
        printf("%d",lista[i]);
    printf("\n");
}

int can(int lista[], int i,int n)
{
    int j;
    for(j=0;j<i;j++)
    {
        if(lista[j]==n || n<0 || n>9)
            return 0;
    }
    return 1;
}

void backtraking(void)
{
    int i=1,j=0,lista[6];
    lista[0]=1;
    while(lista[0]<10)
    {
        while(i<6)
        {
            while(1)
            {
                if(can(lista,i,j))
                {
                    lista[i]=j;
                    j=0;
                    i++;
                    break;
                }
                if(j>8)
                {
                    j=lista[i-1];
                    i--;
                }
                j++;
            }
        }
        printlista(lista);
        i--;
        j=lista[i]+1;
    }
}

void main()
{
    backtraking();
}
