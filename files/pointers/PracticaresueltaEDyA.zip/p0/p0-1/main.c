#include <stdio.h>

void main(void)
{
    int a,b,c,i;
    char Str[10];
    printf("la direccion de\na:%p\nb:%p\nc:%p ",&a,&b,&c);
    for(i=0;i<10;i++)
    {
        printf("\nEl elemento %i es %p",i,&Str[i]);
    }
}
