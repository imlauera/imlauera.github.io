#include <stdio.h>
#include <stdlib.h>

typedef void *VisitorFunc (int);

void recorre(VisitorFunc p, int arreglo[],int largo)
{
    int i;
    for(i=0;i<largo;i++)
    {
        p(arreglo[i]);
    }
}

void print(int i)
{
    printf("\nEscribiste: %d",i);
}

void printints(int arreglo[], int largo)
{
    void (*p)(int);;
    p=&print;
    recorre(p,arreglo,largo);
}

void main()
{
    int i,largo, arreglo[100];
    printf("Cantidad de elementos:\n");
    scanf("%d",&largo);
    for(i=0;i<largo;i++)
    {
        printf("%d :",i+1);
        scanf("%d",&arreglo[i]);
    }
    printints(arreglo,largo);
}
