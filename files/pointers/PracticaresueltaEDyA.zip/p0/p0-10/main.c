#include <stdio.h>
#include <stdlib.h>

struct coordenadas
{
    int x;
    int y;
};

struct coordenadas *medio(struct coordenadas *p1, struct coordenadas *p2)
{
    p1->x=(p1->x+p2->x)/2;
    p1->y=(p1->y+p2->y)/2;
    return p1;
}

void main()
{
    struct coordenadas *p1=malloc(sizeof(struct coordenadas)),*p2=malloc(sizeof(struct coordenadas));
    printf("Ingrese coordenadas de p1:\nx: ");
    scanf("%d",p1->x);
    printf("y: ");
    scanf("%d",&p1->y);
    printf("Ingrese coordenadas de p2:\nx: ");
    scanf("%d",&p2->x);
    printf("y: ");
    scanf("%d",&p2->y);
    p1=medio(p1,p2);
    printf("El punto medio es: (%d, %d)",p1->x,p1->y);
}
