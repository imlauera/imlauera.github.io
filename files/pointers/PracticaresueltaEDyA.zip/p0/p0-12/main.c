#include <stdio.h>
#include <stdlib.h>

void swap(int *p1, int *p2)
{
    int i;
    i=*p1;
    *p1=*p2;
    *p2=i;
}

void main()
{
    int *p1=malloc(sizeof(int));
    int *p2=malloc(sizeof(int));
    printf("Ingrese p1: \n");
    scanf("%d",p1);
    printf("Ingrese p2: \n");
    scanf("%d",p2);
    swap(p1,p2);
    printf("p1: %d\np2: %d",*p1,*p2);
}
