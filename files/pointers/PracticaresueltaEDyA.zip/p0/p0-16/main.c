#include <stdio.h>
#include <stdlib.h>

struct contacto
{
    char nombre[100];
    int tel[100];
    unsigned int edad;
};

int prom(struct contacto *persona, int cant)
{
    int i, cont=0;
    for(i=0;i<cant;i++)
    {
        cont=(persona+i)->edad+cont;
    }
    return cont/cant;
}

void main()
{
    int i,j,cant;
    char c;
    struct contacto *persona=malloc(sizeof(struct contacto)*100);
    printf("Ingrese la cantidad de personas\n");
    scanf("%d",&cant);
    getchar();
    for(i=0;i<cant;i++)
    {
        printf("Ingrese un nombre\n");
        gets((persona+i)->nombre);
        printf("Ingrese el numero\n");
        for(j=0;(c=getchar())!='\n';j++)
        {
            (persona+i)->tel[j]=c-'0';
        }
        (persona+i)->tel[j]='\0';
        printf("Ingrese su edad\n");
        scanf("%d",&(persona+i)->edad);
        getchar();
    }
    i=prom(persona,cant);
    printf("\nEl promedio de las edades es %d",i);
}
