#include <stdio.h>

struct point
{
    float x;
    float y;
};

float area(struct point p1, struct point p2)
{
    float a;
    a=(p1.x-p2.x)*(p1.y-p2.y);
    if(a<0)
        a=-a;
    return a;
}

void main (void)
{
    struct point p1,p2;
    float x,y;
    printf("Ingrese las coordenadas de p1\nx: ");
    scanf("%f",&x);
    printf("y: ");
    scanf("%f",&y);
    p1.x=x;
    p1.y=y;
    printf("Ingrese las coordenadas de p2\nx: ");
    scanf("%f",&x);
    printf("y: ");
    scanf("%f",&y);
    p2.x=x;
    p2.y=y;
    x=area(p1,p2);
    printf("El area del rectangulo definido por p1, p2 es %f",x);
}


