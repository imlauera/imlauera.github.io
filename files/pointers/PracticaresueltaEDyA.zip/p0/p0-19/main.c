#include <stdio.h>
#include <stdlib.h>

int apply(int *f (int), int n)
{
    return f(n);
}

int reloco(int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("\nA re loco");
    }
    n=n-4;
    return n;
}

void main()
{
    int n,(*p)(int);
    printf("Ingrese n:\n");
    scanf("%d",&n);
    p=&reloco;
    n=apply(p,n);
    printf("\nn-4: %d",n);
}
