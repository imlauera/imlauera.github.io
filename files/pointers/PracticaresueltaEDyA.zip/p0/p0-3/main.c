#include <stdio.h>
#include <stdlib.h>

typedef enum{basto,espada,copa,oro} palo;

typedef struct {
    palo p;
    int numero;
}carta;

void main(void)
{
    int i,j;
    palo P[]={basto,espada,copa,oro};
    carta *punt,*mazo;
    punt=malloc(48*sizeof(carta));
    mazo=punt;
    for(j=0;j<4;j++)
    {
        for(i=0;i<12;i++)
        {
            (*mazo).p=P[j];
            (*mazo).numero=i+1;
            mazo++;
        }
    }
    prueba(punt);
    free(punt);
}

void prueba (carta *punt)
{
    char *p[]={&"basto",&"espada",&"copa",&"oro"};
    int i,j;
    for(i=0;i<48;i++)
    {
        printf("\n%i de ",(*punt).numero);
        j=0;
        while(*(p[(*punt).p]+j)!='\0')
        {
            putchar(*(p[(*punt).p]+j));
            j++;
        }
        punt++;
    }
}

