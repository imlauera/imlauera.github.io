#include <stdio.h>
#include <stdlib.h>

char *getnewline(void)
{
    int i;
    char c;
    char *chain=malloc(100);
    for(i=0;((c=getchar())!='\n');i++)
    {
        *(chain+i)=c;
    }
    *(chain+i)='\0';
    return chain;
}

void main()
{
    puts(getnewline());
}
