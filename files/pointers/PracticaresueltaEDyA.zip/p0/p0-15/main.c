#include <stdio.h>
#include <stdlib.h>

struct contacto
{
    char nombre[100];
    int tel[100];
    unsigned int edad;
};

void actualizaredad(struct contacto *contact)
{
    int age;
    printf("\nIngrese la edad nuevamente: ");
    scanf("%d",&age);
    contact->edad=age;
}

void main()
{
    struct contacto *contact=malloc(sizeof(struct contacto));
    int i;
    char c;
    printf("Ingese un nombre: \n");
    gets(contact->nombre);
    printf("Ingese su telefono: \n");
    for(i=0;(c=getchar())!='\n';i++)
    {
        (contact->tel)[i]=c-'0';
    }
    (contact->tel)[i]='\0';
    printf("Ingese su edad: \n");
    scanf("%d",&contact->edad);
    actualizaredad(contact);
    puts(contact->nombre);
    for(i=0;(contact->tel)[i]!='\0';i++)
        {
            printf("%d",(contact->tel)[i]);
        }
    printf("\n%d",contact->edad);
}




