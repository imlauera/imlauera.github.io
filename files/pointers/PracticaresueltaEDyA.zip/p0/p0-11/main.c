#include <stdio.h>


void setin(int *i)
{
    if(*i!=0)
    {
        *i=1;
    }
}

void main()
{
    int *i;
    printf("Ingrese un entero\n");
    scanf("%d",i);
    setin(i);
    printf("%d",*i);
}
