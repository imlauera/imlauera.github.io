#include <stdio.h>

struct agenda
{
    char nombre[20];
    int num;
};

int main()
{
    struct agenda lista[300];
    int cant, j, i;
    int long num;
    char nombre[20],c;
    printf("Ingrese la cantidad de personas que desee agendar: ");
    scanf("%i",&cant);
    for(i=0;i<cant;i++)
    {
        printf("\nIngrese un nombre: ");
        j=0;
        c=getchar();
        while((c=getchar())!='\n')
        {
            lista[i].nombre[j]=c;
            j++;
        }
        lista[i].nombre[j]='\0';
        printf("\nTel: ");
        scanf("%i",&num);
        lista[i].num=num;
    }
    for(i=0;i<cant;i++)
    {
        for(j=0;lista[i].nombre[j]!='\0';j++)
        {
            putchar(lista[i].nombre[j]);
        }
        printf("\t %i\n",lista[i].num);

    }
}
