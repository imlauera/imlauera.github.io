#include <stdio.h>
#include <stdlib.h>


char *itoa2(int n) //itoa ya esta definida en <stdlib.h>
{
    int i;
    char *p;
    p=malloc(12);
    p=p+12;
    *p='\0';
    printf("\n%i\n",abs(n));
    for(i=1;i<=abs(n) || i==1;i=i*10)
    {
        p--;
        *p=(abs(n)%(i*10)-abs(n)%i)/i+'0';
    }
    if(n<0)
    {
        p--;
        *p='-';
    }
    return p;
}



void main(void)
{
    int n;
    char *p;
    printf("Ingrese un numero: ");
    scanf("%i",&n);
    p=itoa2(n);
    while((*p)!='\0')
    {
        printf("%c\n",*p);
        p++;
    }
    free(p-12);
}
