#include <stdio.h>
#include <stdlib.h>

struct contacto
{
    char nombre[100];
    int tel[100];
    unsigned int edad;
};
typedef struct contacto agenda;

void main()
{
    int i,j,cant;
    char c;
    agenda *persona=malloc(sizeof(agenda)*100);
    printf("Ingrese la cantidad de personas\n");
    scanf("%d",&cant);
    getchar();
    for(i=0;i<cant;i++)
    {
        printf("Ingrese un nombre\n");
        gets((persona+i)->nombre);
        printf("Ingrese el numero\n");
        for(j=0;(c=getchar())!='\n';j++)
        {
            (persona+i)->tel[j]=c-'0';
        }
        (persona+i)->tel[j]='\0';
        printf("Ingrese su edad\n");
        scanf("%d",&(persona+i)->edad);
        getchar();
    }
    printf("La agenda es\n");
    for(i=0;i<cant;i++)
    {
        for(j=0;(persona+i)->nombre[j]!='\0';j++)
        {
            printf("%c",(persona+i)->nombre[j]);
        }
        printf("\t");
        for(j=0;(persona+i)->tel[j]!='\0';j++)
        {
            printf("%d",(persona+i)->tel[j]);
        }
        printf("\t");
        printf("\t%d\n",(persona+i)->edad);
    }
}
