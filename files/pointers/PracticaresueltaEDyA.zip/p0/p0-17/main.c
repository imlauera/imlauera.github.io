#include <stdio.h>
#include <stdlib.h>

struct contacto
{
    char nombre[100];
    int tel[100];
    unsigned int edad;
};

struct agenda
{
    struct contacto contact[100];
    int cant;
};

struct agenda *iniciar_agenda(struct agenda *age)
{
    int i,j;
    char c;
    printf("Ingrese la cantidad de personas\n");
    scanf("%d",&age->cant);
    getchar();
    for(i=0;i < age->cant;i++)
    {
        printf("Ingrese un nombre\n");
        gets((age->contact)[i].nombre);
        printf("Ingrese el numero\n");
        for(j=0;(c=getchar())!='\n';j++)
        {
            (age->contact[i].tel)[j]=c-'0';
        }
        (age->contact[i].tel)[j]='10';
        printf("Ingrese su edad\n");
        scanf("%d",&age->contact[i].edad);
        getchar();
    }
}

void baja(struct agenda *agend ,int contact)
{
    int i, j;
    for(i=contact;i<agend->cant;i++)
    {
        for(j=0;agend->contact[i+1].nombre[j]!='\0';j++)
        {
            agend->contact[i].nombre[j]=agend->contact[i+1].nombre[j];
        }
        agend->contact[i].nombre[j]='\0';
        for(j=0;agend->contact[i-1].tel[j]!='10';j++)
        {
            agend->contact[i].tel[j]=agend->contact[i+1].tel[j];
        }
        agend->contact[i].tel[j]='10';
        agend->contact[i].edad=agend->contact[i+1].edad;
    }
    agend->cant=agend->cant-1;
}

void print_agenda(struct agenda *agend)
{
    int i,j;
    printf("La agenda es\n");
    for(i=0;i<agend->cant;i++)
    {
        printf("%d - ",i+1);
        for(j=0;agend->contact[i].nombre[j]!='\0';j++)
        {
            printf("%c",agend->contact[i].nombre[j]);
        }
        printf("\t");
        for(j=0;agend->contact[i].tel[j]!='10';j++)
        {
            printf("%d",agend->contact[i].tel[j]);
        }
        printf("\t%d\n",agend->contact[i].edad);
    }
}

void change_edad(struct agenda *agend, int contact)
{
    printf("\nIngrese la edad nuevamente:\n");
    scanf("%d",&agend->contact[contact].edad);
}


void main()
{
    char c;
    int i;
    struct agenda *agend=malloc(sizeof(struct agenda));
    iniciar_agenda(agend);
    print_agenda(agend);
    printf("\nIngrese el contacto que desea eliminar (0=ninguno) \n");
    scanf("%d",&i);
    if(i!=0 && i<=agend->cant)
    {
        baja(agend,i-1);
    }
    print_agenda(agend);
    printf("\nIngrese el contacto que desea cambiarle la edad (0=ninguno) \n");
    scanf("%d",&i);
    if(i!=0 && i<=agend->cant)
    {
        change_edad(agend,i-1);
    }
    print_agenda(agend);
}
