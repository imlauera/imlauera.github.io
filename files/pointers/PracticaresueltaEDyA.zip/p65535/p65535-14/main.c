#include <stdio.h>

int euclid(int i, int j)
{int m;
    if(j>i)
    {
        m=j;
        j=i;
        i=m;
    }
    if (i%j==0)
        return j;
    else
        return euclid(j,i%j);

}

int main()
{
    int i,j;
    printf("Ingrese 2 numeros \n");
    scanf("%i",&i);
    scanf("%i",&j);
    i=euclid(i, j);
    printf("el maximo comun divisor es %i",i);
}
