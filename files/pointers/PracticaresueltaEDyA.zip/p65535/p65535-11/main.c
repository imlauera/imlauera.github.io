#include <stdio.h>

int lc(void)
{
    int i=0,j;
    char c;
    printf("Ingrese un string \n");
    while((c=getchar())!=EOF)
    {
        if (c=='\n')
            j++;
        i++;
    }
    return i;
}

void main(void)
{
    printf("\n%d",lc());
}
