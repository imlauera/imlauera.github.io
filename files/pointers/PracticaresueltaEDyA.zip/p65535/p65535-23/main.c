#include <stdio.h>

int atoi(char M[])
{
    int i=0,n=0;
    while (M[i]>=48 && M[i]<=57)
    {
        n=n*10+M[i]-48;
        i++;
    }
    return n;
}

void main(void)
{
    int i=0;
    char M[8],c;
    printf("Ingrese un string que represente un entero\n");
    while((c=getchar())>=48 && c<=57)
        {
            M[i]=c;
            i++;
        }
    M[i]='\0';
    i=atoi(M);
    printf("\n%i",i);
}


