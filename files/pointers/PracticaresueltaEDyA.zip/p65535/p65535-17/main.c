#include <stdio.h>

void printints(int M[], int l)
{int i;
    for(i=0;i<l;i++)
    {
        printf("%i\t",M[i]);
    }
}

void main(void)
{
    int l,p[100],i;
    printf("Ingrese la cantidad de numeros\n");
    scanf("%i",&l);
    printf("Ingrese lista de numeros\n");
    for(i=0;i<l;i++)
    {
        scanf("%i",&p[i]);
    }
    printints(p,l);
}
