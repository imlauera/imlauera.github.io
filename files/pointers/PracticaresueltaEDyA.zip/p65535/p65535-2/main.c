#include <stdio.h>

float eval(float a,float b, float c, float x)
{
    a=a*x*x+b*x+c;
    return a;
}

void main(void)
{
    float a,b,c,x,i;
    printf("Ingrese un numero \n");
    scanf("%f",&a);
    printf("Ingrese un numero \n");
    scanf("%f",&b);
    printf("Ingrese un numero \n");
    scanf("%f",&c);
    printf("Ingrese un numero \n");
    scanf("%f",&x);
    i=eval(a,b,c,x);
    printf("El polinomio %f*x^2+%f*x+%f en %f es %f ",a,b,c,x,i);
}
