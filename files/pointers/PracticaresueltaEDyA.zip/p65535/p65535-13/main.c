#include <stdio.h>

void simplecaesar(void)
{
    char c,alf[]="aeiou";
    int i;
    while((c=getchar())!='\n')
    {
        for(i=0;i<5;i++)
        {
            if(c==alf[i])
            {
                c=alf[4-i];
                break;
            }
        }
        putchar(c);
    }
}

void main(void)
{
    simplecaesar();
}
