#include <stdio.h>

int factorial(int i)
{
    if (i==1)
        return i;
    else
        return i*factorial(i-1);
}

void main(void)
{
    int i;
    printf("ingrese el numero del factorial buscado \n");
    scanf("%i",&i);
    i=factorial(i);
    printf("El factorial es %i",i);
}
