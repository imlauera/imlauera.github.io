#include <stdio.h>

int sum(int i)
{
    if (i==1)
        return i;
    else
        return i+sum(i-1);
}

void main(void)
{
    int i;
    printf("ingrese el numero del maximo de la sumatoria buscada \n");
    scanf("%i",&i);
    i=sum(i);
    printf("La sumatoria es %i",i);
}
