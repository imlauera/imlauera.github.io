#include <stdio.h>

int cmpstr(char a[], char b[])
{
    int i=0,j=0;
    while (a[i]!='\0')
    {
        i++;
    }
    while (b[j]!='\0')
    {
        j++;
    }
    if(i!=j)
        return 0;
    else
        for(i=0;i<=j;i++)
    {
        if(a[i]!=b[i])
            return 0;
    }
    return 1;
}


void main(void)
{
    char c,a[1000],b[1000];
    int i=0;
    printf("String 1:\n");
    while((c=getchar())!=EOF)
    {
        a[i]=c;
        i++;
    }
    a[i]='\0';
    printf("\nString 2:\n");
    i=0;
    while((c=getchar())!=EOF)
    {
        b[i]=c;
        i++;
    }
    b[i]='\0';
    i=cmpstr(a,b);
    printf("\n%i",i);
}

