#include <stdio.h>

int factorial(int i)
{int j,f=1;
    for(j=1;j<=i;j++)
    {
        f=f*j;
    }
    return f;
}

void main(void)
{
    int i;
    printf("ingrese el numero del factorial buscado \n");
    scanf("%i",&i);
    i=factorial(i);
    printf("El factorial es %i",i);
}
