#include <stdio.h>

void main(void)
{
    char ant=0,c;
    int i=1;
    printf("Ecriba el programa:\n");
    while((c=getchar())!=EOF)
    {
        if(ant=='/' && c=='*')
            i=0;
        if(ant=='*' && c=='/')
            i=1;
        if(i && c!='/')
            putchar(c);
        ant=c;
    }

}
