#include <stdio.h>

float abs(float f)
{
    if (f<0)
        f=-f;
    return f;
}

void main(void)
{
    float f;
    printf("Ingrese un numero \n");
    scanf("%f",&f);
    f=abs(f);
    printf("%f",f);
}
