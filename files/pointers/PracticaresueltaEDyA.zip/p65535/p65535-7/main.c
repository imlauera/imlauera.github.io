#include <stdio.h>

int bisiesto(int a)
{
    if(a%400==0 || (a%4==0 && a%100!=0))
        return 1;
    else
        return 0;

}

void main(void)
{
    int i;
    printf("Ingrese un a�o \n");
    scanf("%i",&i);
    i=bisiesto(i);
    if(i==0)
        printf("El a�o no es bisiesto ");
    else
        printf("El a�o es bisiesto ");
}

