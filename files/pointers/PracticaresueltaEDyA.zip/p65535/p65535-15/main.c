#include <stdio.h>

int invertir(int n)
{
    int m=0,i,M[100],j=0;
    for(i=1;i<=n;i=i*10)
    {
        M[j]=(n%(i*10)-n%i)/i;
        j++;
    }
    for(i=0;i<j;i++)
    {
        m=m*10+M[i];
    }
    return m;
}

void main(void)
{
    int i;
    printf("Ingrese un numero\n");
    scanf("%i",&i);
    i=invertir(i);
    printf("El numero invertido es: %i",i);
}
