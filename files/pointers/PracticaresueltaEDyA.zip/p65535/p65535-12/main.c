#include <stdio.h>

void echo(void)
{
    char c;
    while((c=getchar())!='\n')
    {
        putchar(c);
    }
}

void main(void)
{
    echo();
}
