#include <stdio.h>
#define contra "lcc"
#define usuario "alumno"



int main(void)
{
    int i=0;
    char c;
    printf("Usuario: \n");
    while((c=getchar())!='\n')
    {
        if (c!=usuario[i] || usuario[i]=='\0')
            printf("\nUsuario invalido");
        i++;
    }
    i=0;
    printf("Contrase�a: \n");
    while((c=getchar())!='\n')
    {
        if (c!=contra[i] || contra[i]=='\0')
            printf("\Contrase�a invalida");
        i++;
    }
    return 0;
}
