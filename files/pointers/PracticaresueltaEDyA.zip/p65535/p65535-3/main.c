#include <stdio.h>

int hasroot(float a, float b, float c)
{
    if (b*b-4*a*c<0)
        return 0;
    if (b*b-4*a*c==0)
        return 1;
    if (b*b-4*a*c>0)
        return 2;
}

void main(void)
{
    float a,b,c,i;
    printf("Ingrese un numero \n");
    scanf("%f",&a);
    printf("Ingrese un numero \n");
    scanf("%f",&b);
    printf("Ingrese un numero \n");
    scanf("%f",&c);
    i=hasroot(a,b,c);
    printf("El polinomio %f*x^2+%f*x+%f tiene %f raices ",a,b,c,i);
}
