#include <stdio.h>

void main(void)
{
    int i;
    printf("Celsius \t Fahrenheit \n");
    for(i=-20;i<=100;i=i+15)
    {
        printf("%i \t \t %f \n",i,(i+(32/1.8f))*1.8f);
    }

}
