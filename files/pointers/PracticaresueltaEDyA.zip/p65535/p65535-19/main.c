#include <stdio.h>

int lenstr(char s[])
{
    int i=0;
    while(s[i]!='\0')
    {
        i++;
    }
    return i;
}



void main(void)
{
    char c,s[1000];
    int i=0;
    printf("String:\n");
    while((c=getchar())!=EOF)
    {
        s[i]=c;
        i++;
    }
    s[i]='\0';
    i=lenstr(s);
    printf("\nEl tienen %i caracteres",i);
}
