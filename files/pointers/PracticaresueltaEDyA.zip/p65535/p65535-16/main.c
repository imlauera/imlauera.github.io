#include <stdio.h>

float prom(int p[],int l)
{
    int sum=0,i;
    for(i=0;i<l;i++)
    {
        sum=sum+p[i];
    }

    return sum/l;
}


void main(void)
{
    float pr;
    int l,p[100],i;
    printf("Ingrese la cantidad de numeros\n");
    scanf("%i",&l);
    printf("Ingrese lista de numeros\n");
    for(i=0;i<l;i++)
    {
        scanf("%i",&p[i]);
    }
    pr = prom(p,l);
    printf("El promedio de los numeros ingresados es %f",pr);
}
