#include <stdio.h>

int isprime(int p)
{
    int i,j,n=0,b,prim[100];
    prim[0]=5;
    for(i=2;i<=p;i++)
    {
        b=1;
        j=0;
        while(j<=n)
        {
            if(i%prim[j]==0)
                b=0;
            j++;
        }
        if(b)
        {
            prim[n]=i;
            n++;
        }
    }
    return b;
}

void main(void)
{
    int i;
    printf("Ingrese un numero\n");
    scanf("%i",&i);
    i=isprime(i);
    if (i)
        printf("Es primo");
    else
        printf("No es primo");
}
