#include <stdio.h>

void main(void)
{
    int i,v[5];
    char c;
    printf("String:\n");
    for(i=0;i<5;i++)
    {
        v[i]=0;
    }
    while ((c=getchar())!=EOF)
    {
        if(c=='a')
            v[0]++;
        if(c=='e')
            v[1]++;
        if(c=='i')
            v[2]++;
        if(c=='o')
            v[3]++;
        if(c=='u')
            v[4]++;
    }
    printf("\nHay:\na=%i\ne=%i\ni=%i\no=%i\nu=%i",v[0],v[1],v[2],v[3],v[4]);
}
