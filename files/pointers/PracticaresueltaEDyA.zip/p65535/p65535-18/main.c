#include <stdio.h>

int isin(int M[], int l, int b)
{
    while (l>0)
    {
        l--;
        if(M[l]==b)
        {
            return 1;
            break;
        }
    }
    return 0;
}

void main(void)
{
    int l,p[100],i,b;
    printf("Ingrese la cantidad de numeros\n");
    scanf("%i",&l);
    printf("Ingrese lista de numeros\n");
    for(i=0;i<l;i++)
    {
        scanf("%i",&p[i]);
    }
    printf("Ingrese el numero buscado\n");
    scanf("%i",&b);
    l=isin(p,l,b);
    printf("%i",l);
}
