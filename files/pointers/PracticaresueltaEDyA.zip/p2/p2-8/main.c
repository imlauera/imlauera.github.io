#include <stdio.h>
#include <stdlib.h>

struct BCTree
{
    int data[127];
    int nelems;
};
typedef struct BCTree BCTree;

int potencia(int b,int p)
{
    int i;
    if(!(p>0))
    {
        return 1;
    }
    else
    {
        return b*potencia(b,p-1);
    }
}

BCTree *cbtree_new(void)
{
    BCTree *arbol=malloc(sizeof(BCTree));
    int alto,i,j=0;
    printf("\nIngrese la altura del arbol\n");
    scanf("%d",&alto);
    arbol->nelems=0;
    for(i=0;i<alto;i++)
    {
        arbol->nelems=potencia(2,i)+arbol->nelems;
    }
    alto=0;
    while(j<arbol->nelems)
    {
        printf("\nPiso %d\n",alto);
        for(i=0;i<potencia(2,alto);i++)
        {
            scanf("%d",&arbol->data[j]);
            j++;
        }
        alto++;
    }
    return arbol;
}

void cbtree_destroy(BCTree *arbol)
{
    if(arbol!=NULL)
    {
        free(arbol);
    }
}

void cbtree_insert(BCTree *arbol,int data)
{
    if(arbol!=NULL)
    {
        arbol->data[arbol->nelems]=data;
        arbol->nelems++;
    }
}

int cbtree_nelements(BCTree *arbol)
{
    return arbol->nelems;
}

void cbtree_foreach(BCTree *arbol,void (*visit)(int data,void *extra_data),void *data)
{
    int i;
    for(i=0;i<arbol->nelems;i++)
    {
        visit(arbol->data[i],data);
    }
}




