#include <stdio.h>
#include <stdlib.h>
#include "BTree.c"

void suma(int data,int *cont)
{
    *cont=*cont+data;
}

int btree_suma(BTree *arbol)
{
    VisitorFuncInt funcion=&suma;
    int c,*cont=malloc(sizeof(int));
    *cont=0;
    btree_foreach(arbol,funcion,cont);
    c=*cont;
    free(cont);
    return c;
}

int btree_cnodos(BTree *arbol)
{
    int cont=1;
    if(arbol==NULL)
    {
        return 0;
    }
    cont=cont+btree_cnodos(arbol->left);
    cont=cont+btree_cnodos(arbol->right);
    return cont;
}

int btree_altura(BTree *arbol)
{
    int cont=1;
    if(arbol==NULL)
    {
        return 0;
    }
    if(btree_altura(arbol->left)<=btree_altura(arbol->right) )
    {
        cont=cont+btree_altura(arbol->right);
    }
    else
    {
        cont=cont+btree_altura(arbol->left);
    }
    return cont;
}

void main()
{
    int cont;
    BTree *arbol=malloc(sizeof(BTree));
    BTree n1, n2, n3, n4;
    n1.data = 12;
    n1.left = &n2;
    n1.right = NULL;
    n2.data = 99;
    n2.left = &n3;
    n2.right = NULL;
    n3.data = 37;
    n3.left = &n4;
    n3.right = NULL;
    n4.data=3;
    n4.left=NULL;
    n4.right=NULL;
    arbol=&n1;
    cont=btree_suma(arbol);
    printf("\n%d",cont);
    cont=btree_cnodos(arbol);
    printf("\n%d",cont);
    cont=btree_altura(arbol);
    printf("\n%d",cont);
    btree_destroy(arbol);
}
