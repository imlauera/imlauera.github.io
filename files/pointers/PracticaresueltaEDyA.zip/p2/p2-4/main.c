#include <stdio.h>
#include <stdlib.h>
#include "BTree.h"
#include "BTree.c"

typedef struct _BTree
{
    int *data;
    struct _BTree *left,*right;
}_BTree;

void menorelemento(int data,int *menor)
{
    if(data<*menor)
    {
        *menor=data;
    }
}

void cambiar_valores(BTree *arbol,int extra_data)
{
    if(arbol!=NULL)
    {
        arbol->data=extra_data;
        cambiar_valores(arbol->left,extra_data);
        cambiar_valores(arbol->right,extra_data);
    }
}

void btree_Menor(BTree *arbol)
{
    VisitorFuncInt menorel;
    int *menor=malloc(sizeof(int));
    btree_foreach(arbol,&menorelemento,menor);
    cambiar_valores(arbol,*menor);
    free(menor);
}

void btree_menor(_BTree *arbol)
{
    if(arbol==NULL)
    {
        return 0;
    }
    if(arbol->left!=NULL)
    {
        if(*arbol->left->data<*arbol->data)
        {
            *arbol->data=*arbol->left->data;
        }
        arbol->left->data=arbol->data;
    }
    if(arbol->right!=NULL)
    {
        if(*arbol->right->data<*arbol->data)
        {
            *arbol->data=*arbol->right->data;
        }
        arbol->right->data=arbol->data;
    }
    btree_menor(arbol->left);
    btree_menor(arbol->right);
}

