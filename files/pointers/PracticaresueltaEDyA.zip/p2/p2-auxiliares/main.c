#include <stdio.h>
#include <stdlib.h>

struct _BCTree
{
    int data[127];
    int nelems;
};
typedef struct _BCTree BCTree;

int potencia(int b,int p)
{
    int i;
    if(!(p>0))
    {
        return 1;
    }
    else
    {
        return b*potencia(b,p-1);
    }
}

BCTree *creararbol(void)
{
    BCTree *arbol=malloc(sizeof(BCTree));
    int alto,i,j=0;
    printf("\nIngrese la altura del arbol\n");
    scanf("%d",&alto);
    arbol->nelems=0;
    for(i=0;i<alto;i++)
    {
        arbol->nelems=potencia(2,i)+arbol->nelems;
    }
    alto=0;
    while(j<arbol->nelems)
    {
        printf("\nPiso %d\n",alto);
        for(i=0;i<potencia(2,alto);i++)
        {
            scanf("%d",&arbol->data[j]);
            j++;
        }
        alto++;
    }
    return arbol;
}



void printarbol(BCTree *arbol)
{
    int i,j=0,alto=0;
    for(i=0;i<arbol->nelems;i++)
    {
        if(i==j)
        {
            printf("\n");
            j=j+potencia(2,alto);
            alto++;
        }
        printf("%d\t",arbol->data[i]);

    }
}

void main()
{
    BCTree *arbol=malloc(sizeof(BCTree));
    arbol=creararbol();
    printarbol(arbol);
    free(arbol);
}
list;




