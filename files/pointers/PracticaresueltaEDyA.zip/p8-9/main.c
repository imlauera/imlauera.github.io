#include <stdio.h>
#include <stdlib.h>

typedef struct _sudoku
{
    int x;
    int y;
    int data;
}sudoku;

typedef struct memory
{
    int last;
    int pos;
}memoria;



sudoku *new_sudoku()
{
    sudoku *sudo=malloc(sizeof(sudoku)*81);
    int i,j;
    for(i=0;i<9;i++)
    {
        for(j=0;j<9;j++)
        {
            (sudo[i*9+j]).y=i+1;
            (sudo[i*9+j]).x=j+1;
            (sudo[i*9+j]).data=0;
        }
    }
    return sudo;
}

void print_sudoku(sudoku *sudo)
{

    int i;
    for(i=0;i<81;i++)
    {
        if((sudo[i].y)%3==1 && sudo[i].x==1)
        {
            printf("+---------+---------+---------+\n");
        }
        if((sudo[i].x)%3==1)
        {
            printf("|");
        }
        printf(" %d ",sudo[i].data);
        if(sudo[i].x==9)
        {
            printf("|\n");
        }
    }
    printf("+---------+---------+---------+\n");
}

int index(sudoku *sudo, int x, int y)
{
    return sudo[(y-1)*9+x-1].data;
}



int is_legal(sudoku *sudo, int i, int data)
{
    int j,n,x,y;
    for(j=1;j<10;j++)
    {
        if(data==index(sudo, sudo[i].x,j) && sudo[i].y!=j)
        {
            return 0;
        }
    }
    for(j=1;j<10;j++)
    {
        if(data==index(sudo, j, sudo[i].y) && sudo[i].x!=j )
        {
            return 0;
        }
    }
    x=sudo[i].x-(sudo[i].x-1)%3;
    y=sudo[i].y-(sudo[i].y-1)%3;
    for(j=0;j<3;j++)
    {
        for(n=0;n<3;n++)
        {
            if(index(sudo,x+j,y+n)==data && sudo[i].x!=x+j && sudo[i].y!=y+n)
            {
                return 0;
            }
        }
    }
    return 1;
}

sudoku *resolverr_sudoku(sudoku *sudo)
{

    int i,j,size=1,cont;
    memoria memo[81];
    memo[0].pos=0;
    for(i=0;i<81;i++)
    {
        memo[i].last=1;
    }
    while(1)
    {
        for(i=memo[size-1].pos;i<81&&cont;i++)
        {
            if(sudo[i].data==0)
            {
                break;
            }
        }
        printf("\n%d",i);
        if(i==81)
            {
                return sudo;
            }
        cont=0;
        for(j=memo[size].last;j<10;j++)
        {
            if(is_legal(sudo,i,j))
            {
                size++;
                sudo[i].data=j;
                cont=1;
                memo[size].last=j;
                memo[size].pos=i;
                break;
            }
            memo[size].last=j;
            memo[size].pos=i;
            size--;
        }
        print_sudoku(sudo);
    }
}

void resolver_sudoku(sudoku *sudo)
{

    int i,j,size=0;
    memoria memo[81];
    for(i=0;i<81;i++)
    {
        if(sudo[i].data==0)
        {
            memo[size].last=0;
            memo[size].pos=i;
            size++;
        }
    }
    i=0;
    while(i<size)
    {
        print_sudoku(sudo);
        for(j=memo[i].last+1;j<10;j++)
        {
            if(is_legal(sudo,memo[i].pos,j))
            {
                sudo[memo[i].pos].data=j;
                memo[i].last=j;
                i++;
                break;
            }
        }
        if(j>9)
        {
            memo[i].last=0;
            sudo[memo[i].pos].data=0;
            i--;
        }
    }
    return sudo;
}

void ingrese_sudoku(sudoku *sudo)
{
    int x,y,d;
    printf("\nPara finalizar ingrese 0 en columnas, en filas y en dato\nPara borrar ingrese las coordenadas y en dato ponga un 0\n\n");
    while(1)
    {
        printf("Columna: ");
        scanf("%d",&x);
        printf("Fila: ");
        scanf("%d",&y);
        printf("Dato: ");
        scanf("%d",&d);
        if(x==0 && y==0 && d==0)
        {
            printf("\n");
            print_sudoku(sudo);
            break;
        }
        if(x<1 || x>9 || d<0 || d>9 || y<1 || y>9)
        {
            printf("Error\n");
        }
        if(is_legal(sudo,(y-1)*9+x-1,d))
        {
            sudo[(y-1)*9+x-1].data=d;
            sudo[(y-1)*9+x-1].x=x;
            sudo[(y-1)*9+x-1].y=y;
        }
        else
            {
                printf("El dato ingresado es incompatible\n");
            }
        print_sudoku(sudo);

    }
}

void main()
{
    sudoku *sudo;
    sudo=new_sudoku();
    ingrese_sudoku(sudo);
    resolver_sudoku(sudo);
    printf("\n\nAL FIN!!!\n\n");
    print_sudoku(sudo);
    free(sudo);
}
