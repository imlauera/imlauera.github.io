#include <stdio.h>
#include <stdlib.h>

struct _objeto
{
    float peso;
    float precio;
};

typedef struct _objeto objeto;

int ordenar(objeto *a, objeto *b)
{
    if(a->precio/a->peso>b->precio/b->peso)
        return -1;
    if(a->precio/a->peso==b->precio/b->peso)
        return 0;
    if(a->precio/a->peso<b->precio/b->peso)
        return 1;
}

void printlist(objeto *lista, int nelems)
{
    int i;
    printf("\n");
    for (i=0;i<nelems;i++)
    {
        printf("%f, ",(lista+i)->precio/(lista+i)->peso);
    }
}

void main()
{
    int (*func) (objeto, objeto);
    int nelems,i;
    float peso,precio=0;
    objeto lista[100];
    func=&ordenar;
    printf("Ingrese la cantidad de elementos:");
    scanf("%d",&nelems);
    for(i=0;i<nelems;i++)
    {
        printf("Ingrese precio del elemento %d\n",i+1);
        scanf("%f",&lista[i].precio);
        printf("Ingrese peso del elemento %d\n",i+1);
        scanf("%f",&lista[i].peso);
    }
    qsort(lista,nelems,sizeof(objeto),func);
    printf("\nIngrese el peso max de la mochilia:\n");
    scanf("%f",&peso);
    printlist(lista,nelems);
    for(i=0;peso>0 && i<nelems;i++)
    {
        if(lista[i].peso<=peso)
            precio+=lista[i].precio;
        if(lista[i].peso>peso)
            precio+=lista[i].precio/lista[i].peso*peso;
        peso-=lista[i].peso;
    }
    free(lista);
    printf("\nEl precio max de lo que se puede llevar en la mochila es %f",precio);
}




