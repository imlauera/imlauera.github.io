#include <stdio.h>
#include <stdlib.h>

typedef struct _AStack
{
    int data[100];
    int back;
}AStack;

AStack *astack_create()
{
    AStack *nuevo=malloc(sizeof(AStack));
    nuevo->back=-1;
    return nuevo;
}

int astack_top(AStack *pila)
{
    if(pila->back!=-1)
    {
        return pila->data[pila->back];
    }
    else
    {
        printf("\nPila vacia");
        exit(0);
    }
}

void astack_push(AStack *pila,int elemento)
{
    pila->back++;
    pila->data[pila->back]=elemento;
}

void astack_pop(AStack *pila)
{
    pila->back--;
}

void astack_reverse(AStack *pila)
{
    int i;
    AStack reverse;
    for(i=0;i<=pila->back;i++)
    {
        reverse.data[i]=pila->data[pila->back-i];
    }
    for(i=0;i<=pila->back;i++)
    {
        pila->data[i]=reverse.data[i];
    }
}

void astack_print(AStack *pila)
{
    int i;
    if(pila->back==-1)
    {
        printf("\nPila vacia");
    }
    for(i=0;i<=pila->back;i++)
    {
        printf("\n%d",pila->data[pila->back-i]);
    }
}

void astack_destroy(AStack *pila)
{
    free(pila);
}


