#include <stdio.h>
#include <stdlib.h>

struct _par
{
    int uno;
    int dos;
};

typedef struct _par par;

int max(a,b)
{
    if (a>b)
        return a;
    else
        return b;
}

int min(a,b)
{
    if (a>b)
        return b;
    else
        return a;
}

par mayor(par a, par b)
{
    if(max(a.uno,a.dos)<min(b.uno,b.dos))
        return b;
    if(min(a.uno,a.dos)>max(b.uno,b.dos))
        return a;
    if(min(a.uno,a.dos)<max(b.uno,b.dos))
    {
        if(a.uno<a.dos)
            a.uno=max(b.uno,b.dos);
        else
            a.dos=max(b.uno,b.dos);
        return a;
    }
    if(min(b.uno,b.dos)<max(a.uno,a.dos))
    {
        if(b.uno<b.dos)
            b.uno=max(a.uno,a.dos);
        else
            b.dos=max(a.uno,a.dos);
        return b;
    }
}

par crear(int a, int b)
{
    par aux;
    aux.uno=a;
    aux.dos=b;
    return aux;
}

par mayores(int lista[], int init, int last)
{
    int a;
    if(init+1==last)
    {
        return crear(lista[init],lista[last]);
    }
    return mayor(mayores(lista,init,last-(last-init+1)/2),mayores(lista,init+((last-init+1)/2),last));
}

void main()
{
    int lista [10];
    lista[0]=3;
    lista[1]=5;
    lista[2]=8;
    lista[3]=3;
    lista[4]=11;
    lista[5]=2;
    lista[6]=3;
    lista[7]=3;
    lista[8]=7;
    lista[9]=3;
    printf("\n%d,%d",mayores(lista,0,9).uno,mayores(lista,0,9).dos);
}
