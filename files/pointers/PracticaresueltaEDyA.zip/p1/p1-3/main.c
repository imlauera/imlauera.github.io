#include <stdio.h>
#include <stdlib.h>
#include "listas.h"

struct comando
{
    int com;
    int v1;
    int v2;
    int v3;
};

struct SL *sl;

struct SL
{
    SList *data;
    SList *next;
};

void create(d)
{
    char c='\0';
    int data;
    SList *list=malloc(sizeof(SList));
    list=NULL;
    printf("\nIngrese elemento:\n");
    while(c!='n')
    {
        scanf("%d",&data);
        list=add_nodo(list,data);
        printf("Ingresar otro elemento? s/n: ");
        getchar();
        scanf("%c",&c);
    }
    if(sl==NULL)
    {
        sl=add_nodo(sl,list);
    }
    else
    {
        slist_insert(sl,list,d);
    }
}

void destroy (int d)
{
    slist_remove(sl,d);
}

void print(int d)
{
    int i;
    struct SL *aux;
    aux=malloc(sizeof(struct SL));
    aux=sl;
    if(sl==NULL)
    {
        printf("\nAca no hay nada");
    }
    else
    {
        for(i=1;i<d;i++)
            {
                aux=aux->next;
            }
        printlist(aux->data);
    }
}

void printall()
{
    struct SL *aux;
    aux=malloc(sizeof(struct SL));
    for(aux=sl;aux->next!=NULL;aux=aux->next)
    {
        printlist(aux->data);
        printf("\n");
    }
    printlist(aux->data);
}

void add_end(int d, int data)
{
    int i;
    struct SL *aux;
    aux=malloc(sizeof(struct SL));
    aux=sl;
    for(i=1;i<d;i++)
    {
        aux=aux->next;
    }
    add_nodo(aux->data,data);
}

void add_beg(int d, int data)
{
    int i;
    struct SL *aux;
    aux=malloc(sizeof(struct SL));
    SList *nuevo=malloc(sizeof(SList));
    nuevo->data=data;
    aux=sl;
    for(i=1;i<d;i++)
    {
        aux=aux->next;
    }
    nuevo->next=aux->data;
    (aux->data)=nuevo;
}

add_pos (int d,int data,int pos)
{
    int i;
    struct SL *aux;
    aux=malloc(sizeof(struct SL));
    aux=sl;
    for(i=1;i<d;i++)
    {
        aux=aux->next;
    }
    slist_insert(aux->data, data,pos);
}

void lenght(int d)
{
    int i;
    struct SL *aux;
    aux=malloc(sizeof(struct SL));
    aux=sl;
    for(i=1;i<d;i++)
    {
        aux=aux->next;
    }
    printf("\n%d",slist_length(aux->data));
}

void concat(int L1, int L2,int L3)
{
    int i;
    struct SL *aux1;
    struct SL *aux2;
    struct SL *aux;
    aux=malloc(sizeof(struct SL));
    aux1=malloc(sizeof(struct SL));
    aux2=malloc(sizeof(struct SL));
    aux=sl;
    for(i=0;i<L1||i<L2;i++)
    {
        if(i==L1-1)
        {
            aux1=aux;
        }
        if(i==L2-1)
        {
            aux2=aux;
        }
        aux=aux->next;
    }
    slist_insert(sl,slist_concat(aux1->data,aux2->data),L3);
}

void remover(int d, int pos)
{
    int i;
    struct SL *aux;
    aux=malloc(sizeof(struct SL));
    aux=sl;
    for(i=1;i<d;i++)
    {
        aux=aux->next;
    }
    slist_remove(aux->data,pos);
}

void contains(int d, int n)
{
    int i;
    struct SL *aux;
    aux=malloc(sizeof(struct SL));
    aux=sl;
    for(i=1;i<d;i++)
    {
        aux=aux->next;
    }
    slist_contains(aux->data,n);
}

void index(int d, int n)
{
    int i;
    struct SL *aux;
    aux=malloc(sizeof(struct SL));
    aux=sl;
    for(i=1;i<d;i++)
    {
        aux=aux->next;
    }
    for(i=1;aux->data->next!=NULL;i++)
    {
        if(aux->data->data==n)
        {
            printf("\n%d",i);
        }
        aux->data=aux->data->next;
    }
    if(aux->data->data==n)
        {
            printf("\n%d",i);
        }
}

void intersect(int L1, int L2,int L3)
{
    int i;
    struct SL *aux1;
    struct SL *aux2;
    struct SL *aux;
    aux=malloc(sizeof(struct SL));
    aux1=malloc(sizeof(struct SL));
    aux2=malloc(sizeof(struct SL));
    aux=sl;
    for(i=0;i<L1||i<L2;i++)
    {
        if(i==L1-1)
        {
            aux1=aux;
        }
        if(i==L2-1)
        {
            aux2=aux;
        }
        aux=aux->next;
    }
    slist_insert(sl,slist_intersect(aux1->data,aux2->data),L3);
}

struct comando *cmd(char palabra[])
{
    int i,j;
    struct comando *com;
    com=malloc(sizeof(struct comando));
    com->com=-1;
    com->v1=0;
    com->v2=0;
    com->v3=0;
    char *lcomandos[]={&"create",&"destroy",&"print",&"add_end",&"add_beg",&"add_pos",&"lenght",&"concat",&"remover",&"contais",&"index",&"intersec"};
    for(i=0;i<12;i++)
    {
        for(j=0;palabra[j]==*(lcomandos[i]+j) || palabra[j]==' ';j++)
        {
            if (palabra[j]==' ')
            {
                com->com=i;
                break;
            }
        }
    }
    if(com->com==-1)
    {
        return NULL;
    }
    for(i=0;palabra[i]!=' ';i++)
    {
          if(palabra[i]=='\n')
          {
              printf("\nHOLA 1");
              return NULL;
          }
    }
    i++;
    if(!(palabra[i]>=48 && palabra[i]<=57))
    {
        return NULL;
    }
    while (palabra[i]>=48 && palabra[i]<=57)
    {
        com->v1=com->v1*10+palabra[i]-48;
        i++;
    }
    if(palabra[i]=='\0')
    {
        return com;
    }
    if(palabra[i]!=' ')
    {
        return NULL;
    }
    i++;
    while (palabra[i]>=48 && palabra[i]<=57)
    {
        com->v2=com->v2*10+palabra[i]-48;
        i++;
    }
    if(palabra[i]=='\n')
    {
        return com;
    }
    if(palabra[i]!=' ')
    {
        return NULL;

    }
    i++;
    while (palabra[i]>=48 && palabra[i]<=57)
    {
        com->v3=com->v3*10+palabra[i]-48;
        i++;
    }
    if(palabra[i]!='\0')
    {
        return NULL;
    }
    return com;
}



void main()
{
    int i;
    char palabra[100],c;
    struct comando *com;
    com=malloc(sizeof(sizeof(struct comando)));
    while(1)
    {

        for(i=0;(c=getchar())!='\n';i++)
        {
            palabra[i]=c;
        }
        palabra[i]='\0';
        com=cmd(palabra);
        if(com==NULL && i!=0)
        {
            printf("\nCOMAND FAILURE 1");
        }
        if(com!=NULL)
        {
            switch(com->com)
            {
                case 0:
                    if(com->v2==0 && com->v3==0)
                    {
                        create(com->v1);
                        break;
                    }
                    printf("\nCOMAND FAILURE");
                    break;
                case 1:
                    if(com->v2==0 && com->v3==0)
                    {
                        destroy(com->v1);
                        break;
                    }
                    printf("\nCOMAND FAILURE");
                    break;
                case 2:
                    if(com->v2==0 && com->v3==0)
                    {
                        print(com->v1);
                        printf("\n");
                        break;
                    }
                    printf("\nCOMAND FAILURE");
                    break;
                case 3:
                    if(com->v2!=0 && com->v3==0)
                    {
                        add_end(com->v1,com->v2);
                        break;
                    }
                    printf("\nCOMAND FAILURE");
                    break;
                case 4:
                    if(com->v2!=0 && com->v3==0)
                    {
                        add_beg(com->v1,com->v2);
                        break;
                    }
                    printf("\nCOMAND FAILURE");
                    break;
                case 5:
                    if(com->v2!=0 && com->v3!=0)
                    {
                        add_pos(com->v1,com->v2,com->v3);
                        break;
                    }
                    printf("\nCOMAND FAILURE");
                    break;
                case 6:
                    if(com->v2==0 && com->v3==0)
                    {
                        lenght(com->v1);
                        break;
                    }
                    printf("\nCOMAND FAILURE");
                    break;
                case 7:
                    if(com->v2!=0 && com->v3!=0)
                    {
                        concat(com->v1,com->v2,com->v3);
                        break;
                    }
                    printf("\nCOMAND FAILURE");
                    break;
                case 8:
                    if(com->v2!=0 && com->v3==0)
                    {
                        remover(com->v1,com->v2);
                        break;
                    }
                    printf("\nCOMAND FAILURE");
                    break;
                case 9:
                    if(com->v2!=0 && com->v3==0)
                    {
                        contains(com->v1,com->v2);
                        break;
                    }
                    printf("\nCOMAND FAILURE");
                    break;
                case 10:
                    if(com->v2!=0 && com->v3==0)
                    {
                        index(com->v1,com->v2);
                        break;
                    }
                    printf("\nCOMAND FAILURE");
                    break;
                case 11:
                    if(com->v2!=0 && com->v3!=0)
                    {
                        intersect(com->v1,com->v2,com->v3);
                        break;
                    }
                    printf("\nCOMAND FAILURE");
                    break;
                case 12:
                    printf("\nCOMAND FAILURE");
                    break;
            }
        }
    }
}

