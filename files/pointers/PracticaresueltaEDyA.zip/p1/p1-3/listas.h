#include <stdio.h>
#include <stdlib.h>

struct nodo{
    int data;
    struct nodo *next;
};
typedef struct nodo SList;

void slist_has_next(SList *nodo)
{
    if(nodo->next==NULL)
    {
        printf("\nNo hay proximo nodo");
    }
    if(nodo->next!=NULL)
    {
        printf("\nExiste un proximo nodo");
    }
}

int slist_length(SList *nodo)
{
    int i;
    for(i=1;nodo->next!=NULL;i++)
    {
        nodo=nodo->next;
    }
    return i;
}

SList *slist_concat(SList *nodo1,SList *nodo2)
{
    SList *p;
    p=nodo1;
    while(p->next!=NULL)
    {
        p=p->next;
    }
    p->next=nodo2;
    return nodo1;
}

void slist_insert(SList *nodo,void *data,int d)
{
    int i;
    SList *new_data=malloc(sizeof(SList));
    new_data->data=data;
    if(d==1)
    {
        data=nodo->data;
        nodo->data=new_data->data;
        slist_insert(nodo, data, 2);
    }
    else
    {
        for(i=0;i<d-2;i++)
        {
            nodo=nodo->next;
        }
        new_data->next=nodo->next;
        nodo->next=new_data;
    }
}

void slist_remove (SList *nodo, int d)
{
    int i;
    if(d==1)
    {
        nodo->data=nodo->next->data;
        slist_remove(nodo,2);
    }
    else
    {
        for(i=0;i<d-2;i++)
        {
            nodo=nodo->next;
        }
        nodo->next=nodo->next->next;
    }
}

void slist_contains(SList *nodo, int dato)
{
    while(nodo->next!=NULL)
    {
        if(nodo->data==dato)
        {
            printf("\nSI");
            return 0;
        }
        nodo=nodo->next;
    }
    printf("\nNO");
}

unsigned int slist_index(SList *nodo, int data)
{
    int i;
    for(i=1;nodo->next!=NULL;i++)
    {
        if(nodo->data==data)
        {
            return i;
        }
        nodo=nodo->next;
    }
    if(nodo->data==data)
        {
            return i;
        }
    return 0;
}

SList *add_nodo(SList *nodo,void *data)
{
    SList *nuevo=malloc(sizeof(SList)),*aux=malloc(sizeof(SList));
    aux=nodo;
    nuevo->data=data;
    nuevo->next=NULL;
    if(nodo!=NULL)
    {
        while(aux->next!=NULL)
        {
            aux=aux->next;
        }
    aux->next=nuevo;
    }
    else
    {
        nodo=nuevo;
    }
    return nodo;
}


SList *slist_intersect(SList *list1,SList *list2)
{
    SList *nuevo=malloc(sizeof(SList)),*aux=malloc(sizeof(SList));
    nuevo=NULL;
    for(;list1!=NULL;list1=list1->next)
    {
        for(aux=list2;aux!=NULL;aux=aux->next)
        {
            if(list1->data==aux->data  && (nuevo==NULL || !(slist_index(nuevo,aux->data))))
            {
                nuevo=add_nodo(nuevo,list1->data);
            }
        }
    }
    return nuevo;
}

SList *slist_intermsect_custom (SList *list1, SList *list2, int (*p) (int,int))
{
    SList *nuevo=malloc(sizeof(SList)),*aux=malloc(sizeof(SList));
    nuevo=NULL;
    for(;list1!=NULL;list1=list1->next)
    {
        for(aux=list2;aux!=NULL;aux=aux->next)
        {
            if(p(list1->data,aux->data) && (nuevo==NULL || !(slist_index(nuevo,aux->data))))
            {
                nuevo=add_nodo(nuevo,list1->data);
            }
        }
    }
    return nuevo;
}

int aux (int a, int b)
{
    if(a>b)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

void printlist (SList *list)
{
    for(;list->next!=NULL;list=list->next)
    {
        printf("\n%d",list->data);
    }
    printf("\n%d",list->data);
}

