#include <stdio.h>
#include <stdlib.h>

struct nodo{
    int data;
    struct nodo *next;
};
typedef struct nodo SList;

void slist_has_next(SList *nodo)
{
    if(nodo->next==NULL)
    {
        printf("\nNo hay proximo nodo");
    }
    if(nodo->next!=NULL)
    {
        printf("\nExiste un proximo nodo");
    }
}

int slist_length(SList *nodo)
{
    int i;
    for(i=1;nodo->next!=NULL;i++)
    {
        nodo=nodo->next;
    }
    return i;
}

SList *slist_concat(SList *nodo1,SList *nodo2)
{
    SList *p;
    p=nodo1;
    while(p->next!=NULL)
    {
        p=p->next;
    }
    p->next=nodo2;
    return nodo1;
}

void slist_insert(SList *nodo, int data, int d)
{
    int i;
    SList *new_data=malloc(sizeof(SList));
    new_data->data=data;
    if(d==1)
    {
        data=nodo->data;
        nodo->data=new_data->data;
        slist_insert(nodo, data, 2);
    }
    else
    {
        for(i=0;i<d-2;i++)
        {
            nodo=nodo->next;
        }
        new_data->next=nodo->next;
        nodo->next=new_data;
    }
}

void slist_remove (SList *nodo, int d)
{
    int i;
    if(d==1)
    {
        nodo->data=nodo->next->data;
        slist_remove(nodo,2);
    }
    else
    {
        for(i=0;i<d-2;i++)
        {
            nodo=nodo->next;
        }
        nodo->next=nodo->next->next;
    }
}

void slist_contains(SList *nodo, int dato)
{
    while(nodo->next!=NULL)
    {
        if(nodo->data==dato)
        {
            printf("\nEl elemento se encuentra en la lista");
            return 0;
        }
        nodo=nodo->next;
    }
    printf("\nEl elemento no encuentra en la lista");
}

unsigned int slist_index(SList *nodo, int data)
{
    int i;
    for(i=1;nodo->next!=NULL;i++)
    {
        if(nodo->data==data)
        {
            return i;
        }
        nodo=nodo->next;
    }
    return 0;
}

SList *add_nodo(SList *nodo,int data)
{
    SList *nuevo=malloc(sizeof(SList)),*aux=malloc(sizeof(SList));
    aux=nodo;
    nuevo->data=data;
    nuevo->next=NULL;
    if(nodo!=NULL)
    {
        while(aux->next!=NULL)
        {
            aux=aux->next;
        }
    aux->next=nuevo;
    }
    else
    {
        nodo=nuevo;
    }
    return nodo;
}


SList *slist_intersect(SList *list1,SList *list2)
{
    SList *nuevo=malloc(sizeof(SList)),*aux=malloc(sizeof(SList));
    nuevo=NULL;
    for(;list1!=NULL;list1=list1->next)
    {
        for(aux=list2;aux!=NULL;aux=aux->next)
        {
            if(list1->data==aux->data)
            {
                nuevo=add_nodo(nuevo,list1->data);
            }
        }
    }
    return nuevo;
}

SList *slist_intermsect_custom (SList *list1, SList *list2, int (*p) (int,int))
{
    SList *nuevo=malloc(sizeof(SList)),*aux=malloc(sizeof(SList));
    nuevo=NULL;
    for(;list1!=NULL;list1=list1->next)
    {
        for(aux=list2;aux!=NULL;aux=aux->next)
        {
            if(p(list1->data,aux->data))
            {
                nuevo=add_nodo(nuevo,list1->data);
            }
        }
    }
    return nuevo;
}

int aux (int a, int b)
{
    if(a>b)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

void printlist (SList *list)
{
    for(;list->next!=NULL;list=list->next)
    {
        printf("\n%d",list->data);
    }
    printf("\n%d",list->data);
}

void main()
{
    int i;
    int (*f)(int,int);
    SList n1,n2,n3,n4,n5,n10,n20,n30,n40,n50,*list1,*list2,*nuevo=malloc(sizeof(SList));
    list1=&n1;
    n1.next=&n2;
    n2.next=&n3;
    n3.next=&n4;
    n4.next=&n5;
    n5.next=NULL;
    n1.data=1;
    n2.data=2;
    n3.data=3;
    n4.data=4;
    n5.data=5;
    list2=&n10;
    n10.next=&n20;
    n20.next=&n30;
    n30.next=&n40;
    n40.next=&n50;
    n50.next=NULL;
    n10.data=6;
    n20.data=3;
    n30.data=1;
    n40.data=2;
    n50.data=0;
    nuevo=NULL;
    f=aux;
    nuevo=slist_intermsect_custom(list1,list2,f);
    printlist(nuevo);
}
