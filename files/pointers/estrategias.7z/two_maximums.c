#include <stdio.h>
#include <stdlib.h>

int *MAX42(int *a, int *b) {
			int aux[4];
			int *ret = malloc(sizeof(int)*2);
			
			aux[0] = a[0];
			aux[1] = a[1];
			aux[2] = b[0];
			aux[3] = b[1];
			
			int max, snd_max, i;
			
			if(aux[0] > aux[1])
			{
			    max = 0;
			    snd_max = 1;
			    
			}else{
			    
			    snd_max = 0;
			    max = 1;
			}
			
			for(i = 2 ; i < 4; i++)
			{
			    if(aux[i] >= aux[max])
			    {
			      
			        snd_max = max;
			        max = i;
			    
			    }else if(aux[i] > aux[snd_max]){
			        
			        snd_max = i;
			    
			    }
			}
			
			ret[0] = aux[max];
			ret[1] = aux[snd_max];
			
			return ret;
}

int *solve(int list[], int init, int last) {
	
	int len = (last-init)+1;
	int *max2 = malloc(sizeof(int)*2);
	
	if(len != 1) {
		
		if(len == 2)
		{
			max2[0] = list[init];
			max2[1] = list[last];
			return max2;
		}
		
		if(len == 3)
		{
			int max, snd_max, i;
			if(list[init] > list[init+1])
			{
			    max = init;
			    snd_max = init+1;
			}else{
			    snd_max = init;
			    max = init+1;
			}
			
			for(i = init+2 ; i <= last; i++)
			{
			    if(list[i] >= list[max])
			    {
			        snd_max = max;
			        max = i;
			    }else if(list[i] > list[snd_max]){
			        snd_max = i;
			    }
			}
			
			max2[0] = list[max];
			max2[1] = list[snd_max];
			
			return max2;
		
		}else{
			
			int pivot = last/2;
			int *sub1, *sub2;
			
			sub1 = solve(list, init, pivot);
			sub2 = solve(list, pivot+1,last);
			
			max2 = MAX42(sub1,sub2);
			
			free(sub1);
			free(sub2);
			
			return max2;
		}
	}
}

int main(void) {
    int list[7] = {54,3,56,2,5,7,256};
    int *ret;
    ret = solve(list,0,6);
    printf("Los dos maximos son %i y %i\n",ret[0],ret[1]);
	return 0;
}