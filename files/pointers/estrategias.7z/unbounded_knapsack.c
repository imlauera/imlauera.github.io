#include <stdio.h>
#include <stdlib.h>

typedef struct _obj {
	int number, value, weight;
} obj;

void solve(obj list[], int sz, int W) {
	int ret[W+1], sol[sz];
	int i,C;
	
	ret[0]=0;
	
	for(C=1;C<=W;C++)
	{
		for(i=0;i<sz;i++)
		{
			if(list[i].weight <= C)
				sol[i] = ret[C-list[i].weight] +list[i].value;
			else
				sol[i] = 0;
		}
	
		ret[C] = sol[0];
		for(i=1;i < sz;i++)
		{
			if(sol[i] > ret[C])
				ret[C] = sol[i];
		}
	}
	
	printf("El valor optimo es de %i\n", ret[W]);	
}

int main(void) {
	int number_of_objects, i, maxw;
	obj *objs;
	
	printf("Ingrese la cantidad de objetos: ");
	scanf("%i",&number_of_objects);
	objs = malloc(sizeof(obj)*number_of_objects);
	
	printf("Ingrese el espacio en peso de la mochila: ");
	scanf("%i",&maxw);
	
	for(i=0;i<number_of_objects;i++)
	{
		objs[i].number = i;
		printf("Ingrese el valor del objeto %i: ",objs[i].number);
		scanf("%i",&objs[i].value);
		printf("Ingrese el peso del objeto %i: ",objs[i].number);
		scanf("%i",&objs[i].weight);
	}
	
	for(i=0;i<number_of_objects;i++)
	{
		printf("Objeto %i de valor %i y peso %i\n", objs[i].number,objs[i].value,objs[i].weight);
	}
	
	solve(objs, number_of_objects, maxw);
	
	free(objs);
	
	return 0;
}