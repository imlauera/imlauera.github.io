#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MIN3(a, b, c) ((a) < (b) ? ((a) < (c) ? (a) : (c)) : ((b) < (c) ? (b) : (c)))

int min(int a, int b) {
	if(a>=b)
		return a;
	else
		return b;
}

int cmp(char wrd1[], char wrd2[], int pos1, int pos2) {
	if(wrd1[pos1] != wrd2[pos2])
		return 1;
	else
		return 0;
}

int solve(char wrd1[], char wrd2[]) {
	int i, j, len1 = strlen(wrd1), len2 = strlen(wrd2);	
	int table[len1+1][len2+1];
	
	table[0][0] = 0;
	
	for(i=0 ; i<=len1+1 ; i++)
		table[i][0] = i;
	
	for(j=0 ; j<=len2+1 ; j++)
		table[0][j] = j;
	
	for(i=1 ; i<=len1+1 ; i++)
	{
		for(j=1 ; j<=len2+1 ; j++)
		{
			table[i][j] = MIN3( table[i-1][j-1]+cmp(wrd1,wrd2,i-1,j-1) , table[i-1][j]+1 , table[i][j-1]+1 );
		}
	}
	return table[len1+1][len2+1];
}

int main(void) {
	char wrd1[32], wrd2[32];
	printf("Ingrese la primer palabra: ");
	scanf("%s",&wrd1);
	printf("Ingrese la segunda palabra: ");
	scanf("%s",&wrd2);
	printf("La distancia entre %s y %s es %i\n",wrd1,wrd2,solve(wrd1,wrd2));
}