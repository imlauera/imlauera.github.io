#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int max(int a, int b) {
	if(a>=b)
		return a;
	else
		return b;
}

int lcs(char *wrd1, int len1, char *wrd2, int len2) {
	int dp[len1+1][len2+1],i,j;
	for(i=0;i<=len1;i++)
	{
		for(j=0;j<=len2;j++)
		{
			if(j==0 || i==0)
				dp[i][j] = 0;
			else if(wrd1[i-1] == wrd2[j-1])
				dp[i][j] = 1 + dp[i-1][j-1];
			else
				dp[i][j] = max(dp[i-1][j],dp[i][j-1]);
		}
	}
	
	int index = dp[len1][len2];
	char lcs_wrd[index+1];
	lcs_wrd[index] = '\0';
	index--;
	i = len1;
	j = len2;
	while(i>0 && j>0)
	{
		if(wrd1[i-1] == wrd2[j-1])
		{
			lcs_wrd[index--] = wrd1[i-1];
			i--;
			j--;
		}else if(dp[i-1][j] > dp[i][j-1])
			i--;
		else
			j--;
	}
	printf("LCS es: %s\n",lcs_wrd);
	return dp[len1][len2];
}

int main(void) {
	char wrd1[7] = "AGGTAB", wrd2[8] = "GXTXAYB";
	int len1 = strlen(wrd1), len2 = strlen(wrd2);
	printf("LCS de '%s' y '%s' = %i",wrd1,wrd2,lcs(wrd1,len1,wrd2,len2));
	return 0;
}