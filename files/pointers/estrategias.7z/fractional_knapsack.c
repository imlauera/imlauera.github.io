#include <stdio.h>
#include <stdlib.h>

typedef struct _obj {
	int number, value, weight;
} obj;

int obj_cmp(const void *aa, const void *bb)
{
	const obj *a = aa, *b = bb;
	double ua = a->v / a->w, ub = b->v / b->w;
	return ua < ub ? -1 : ua > ub;
}

void solve(obj list[], int sz, int W) {
	
	int i, currw = 0, used[sz];
	float currval = 0.0;
	
	printf("Ordenamos los objetos de acuerdo a su relacion precio/peso: \n");
	
	qsort(list, sz, sizeof(obj), obj_cmp);
	
	for(i=0;i<sz;i++)
	{
		printf("Objeto %i con relacion %f\n", list[i].number, (float)(list[i].value) / (float)(list[i].weight) );
	}
	
	for(i=0;i<sz;i++)
	{
		used[list[i].number] = 0;
	}
	
	for(i=0;i<sz;i++)
	{
		if(currw + list[i].weight <= W && used[list[i].number] != 1)
		{
			used[list[i].number] = 1;
			currw = currw + list[i].weight;
			currval = currval + list[i].value;
		
		}else if(W - currval != 0 && used[list[i].number] != 1)
			{
				used[list[i].number] = 1;
				currval = currval + ((float)list[i].value / (float)list[i].weight)*(float)(W-currval);
				currw = W;
			}
	}
	
	printf("Se ocupo %i de espacio y hay %f pesos\n", currw, currval);
}

int main(void) {
	int number_of_objects, i, maxw;
	obj *objs;
	
	printf("Ingrese la cantidad de objetos: ");
	scanf("%i",&number_of_objects);
	objs = malloc(sizeof(obj)*number_of_objects);
	
	printf("Ingrese el espacio en peso de la mochila: ");
	scanf("%i",&maxw);
	
	for(i=0;i<number_of_objects;i++)
	{
		objs[i].number = i;
		printf("Ingrese el valor del objeto %i: ",objs[i].number);
		scanf("%i",&objs[i].value);
		printf("Ingrese el peso del objeto %i: ",objs[i].number);
		scanf("%i",&objs[i].weight);
	}
	
	for(i=0;i<number_of_objects;i++)
	{
		printf("Objeto %i de valor %i y peso %i\n", objs[i].number,objs[i].value,objs[i].weight);
	}
	
	solve(objs, number_of_objects, maxw);
	
	free(objs);
	
	return 0;
}