#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int min(int x, int y, int z)
{
   if (x < y)
      return (x < z)? x : z;
   else
      return (y < z)? y : z;
}

int arr_min(int arr[], int sz)
{
	int min = 0,i;
	for(i=1;i<sz;i++)
	{
		if(arr[i] <= arr[min])
			min = i;
	}
	
	return min;
}

int solve(int n, int c[][n]) {
	
	int i , j, dp[n][n+2], mins[n];
	
	for(j=1;j<=n;j++)
		dp[n-1][j] = c[n-1][j];
	
	for(i=0;i<n;i++)
	{
		dp[i][0] = INT_MAX;
		dp[i][n+1] = INT_MAX;
	}
	
	for(i=n-1;i>=0;i--)
	{
		for(j=1;j<=n;j++)
		{
			dp[i][j] = min(dp[i+1][j-1], dp[i+1][j], dp[i+1][j+1]) + c[i][j];
		}
	}
	
	for(j=1;j<=n;j++)
	{
		mins[j-1] = dp[0][j];
	}
	
	return mins[arr_min(mins,n)];
}

int main(void) {
	int c[3][3] = { {5, 5, 1},
                    {5, 5, 1},
                    {5, 1, 5} };
   printf(" %i\n", solve(3, c));
	return 0;
}
