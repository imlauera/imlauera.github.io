#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>

typedef struct _point {
	
	int x, y;

} point;

float dist(point a, point b) {
	
	return sqrt(pow(a.x-b.x,2)+pow(a.y-b.y,2));
}

int X_comp(const void *a, const void *b) {
	
	point *p1 = (point *)a, *p2 = (point *)b;
	
	return (p1->x - p2->x);
}

int Y_comp(const void *a, const void *b) {
	
	point *p1 = (point *)a, *p2 = (point *)b;
	
	return (p1->y - p2->y);
}

float min(float x, float y)
{
    return (x < y)? x : y;
}

float brutforce(point P[], int sz) {
	
	int i,j,min = FLT_MAX;
	
	for(i=0;i<sz;i++)
	{
		for(j=i+1;j<sz;j++)
		{
			if(dist(P[i],P[j]) < min)
				min = dist(P[i],P[j]);
		}
	}
	
	return min;
}

float minstrip_dist(point strip[], int sz, float d) {
	
	float min = d;
	int i , j;
	
	qsort(strip, sz, sizeof(point), Y_comp);
	
	for(i=0;i<sz;i++)
	{
		for(j=i+1; j < sz && (strip[j].y - strip[i].y) < min; j++)
		{
			if( dist(strip[i],strip[j]) < min)
				min = dist(strip[i],strip[j]);
		}
	}
	
	return min;
}

float minpoint_dist_util(point P[], int sz) {
	
	if(sz <= 3)
		return brutforce(P, sz);
	
	int i,j, mid = sz/2;
	point midpoint = P[mid];
	
	float dl = minpoint_dist_util(P, mid),
	dr = minpoint_dist_util(P + mid, sz - mid);
	
	float d = min(dl,dr);
	
	point strip[sz];
	j = 0;
	
	for(i=0;i<sz;i++)
	{
		if(abs(P[i].x - midpoint.x) < d)
		{
			strip[j] = P[i];
			j++;
		}
	}
	return min( d , minstrip_dist(strip, sz, d));
}

float minpoint_dist(point P[], int sz) {
	
	qsort(P, sz, sizeof(point), X_comp);
	
	return minpoint_dist_util(P,sz);
}

int main(void) {
	point P[] = {{2, 3}, {12, 30}, {40, 50}, {5, 1}, {12, 10}, {3, 4}};
    int n = sizeof(P) / sizeof(P[0]);
    printf("The smallest distance is %f ", minpoint_dist(P, n));
    return 0;
}