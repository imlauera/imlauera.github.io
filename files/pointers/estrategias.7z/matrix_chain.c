#include <stdio.h>
#include <limits.h>

void print_sol(int n, int list[][n], int i, int j) {
	if(i == j)
		printf("A%i",i);
	else{
	    putchar('(');
		print_sol(n, list,i,list[i][j]);
		print_sol(n, list,list[i][j]+1,j);
		putchar(')');
	}
}

int matrix_chain(int list[], int n) {
	
	int m[n+1][n+1], s[n+1][n+1];
	int i,j,k,L,q;
	
	for(i=0;i<=n;i++)
		m[i][i] = 0;
	
	for(L=2 ; L <= n; L++)
	{
		for( i=1 ; i <= n-L+1 ; i++)
		{
			j = i+L-1;
			m[i][j] = INT_MAX;
			for(k=i; k < j; k++)
			{
				q = m[i][k] + m[k+1][j] + list[i-1]*list[k]*list[j];
				if(q < m[i][j])
				{
					m[i][j] = q;
				    s[i][j] = k;
				}
			}
		}
	}
	print_sol(n+1,s,1,n);
	puts("");
	return m[1][n];
}

int main(void) {
	int matrixes[7] = {30,35,15,5,10,20,25}, n = 6;
	printf("%i\n", matrix_chain(matrixes, n));
	return 0;
}