#include <stdio.h>
#include <stdlib.h>

int max(int a, int b) {
	if(a>=b)
		return a;
	else
		return b;
}

typedef struct _obj {
	int value, weight;
} obj;

int solve(obj list[], int sz, int W) {
	
	int i , j, restCap;
	int table[sz+1][W+1];
	
	for(j=0;j<=W;j++)
		table[sz][j] = 0;
	
	for(i=sz-1;i>=0;i--)
	{
		for(j=0;j<=W;j++)
		{
			if(j >= (list[i].weight))
			{
			    restCap = j- list[i].weight;
				table[i][j] = max( table[i+1][j] , ((list[i].value) + table[i+1][restCap]));
			
			}else{
				table[i][j] = table[i+1][j];
			}
		}
	}
	return table[0][W];
}

int main(void) {
    obj list[3] = {{10,4},{4,2},{7,3}};
	int maxw = 5;
	printf("Para una mochila de capacidad %i se obtiene %i de valor\n", maxw, solve(list,3,maxw));
	return 0;
}